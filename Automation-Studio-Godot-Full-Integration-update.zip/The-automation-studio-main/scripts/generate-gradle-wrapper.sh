#!/usr/bin/env sh
# Generate the official Gradle Wrapper files for this project.
# Run from the repository root on a machine with Gradle 9.3.1 (or compatible) installed.
set -eu
EXPECTED_VERSION="9.3.1"
EXPECTED_WRAPPER_SHA256="b3a875ddc1f044746e1b1a55f645584505f4a10438c1afea9f15e92a7c42ec13"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Install Gradle ${EXPECTED_VERSION}, then rerun this script." >&2
  exit 127
fi
ACTUAL_VERSION="$(gradle --version | sed -n 's/^Gradle \([0-9][^ ]*\)$/\1/p' | head -n 1)"
if [ -z "$ACTUAL_VERSION" ]; then
  echo "Could not detect the installed Gradle version." >&2
  exit 1
fi
if [ "$ACTUAL_VERSION" != "$EXPECTED_VERSION" ]; then
  echo "This project pins Gradle ${EXPECTED_VERSION}; installed version is ${ACTUAL_VERSION}." >&2
  echo "Install/use Gradle ${EXPECTED_VERSION} to avoid wrapper-version drift." >&2
  exit 1
fi
gradle wrapper --gradle-version "$EXPECTED_VERSION" --distribution-type bin
ACTUAL_WRAPPER_SHA256="$(sha256sum gradle/wrapper/gradle-wrapper.jar | awk '{print $1}')"
if [ "$ACTUAL_WRAPPER_SHA256" != "$EXPECTED_WRAPPER_SHA256" ]; then
  echo "Wrapper JAR checksum mismatch; refusing to accept an unverified JAR." >&2
  echo "Expected: $EXPECTED_WRAPPER_SHA256" >&2
  echo "Actual:   $ACTUAL_WRAPPER_SHA256" >&2
  exit 1
fi
printf '%s  %s\n' "$EXPECTED_WRAPPER_SHA256" "gradle/wrapper/gradle-wrapper.jar" > gradle/wrapper/gradle-wrapper.jar.sha256
printf '\nGenerated and checksum-verified: gradlew, gradlew.bat, gradle/wrapper/gradle-wrapper.jar\n'
printf 'Next: ./gradlew --version\n'
