# Native Build Pipeline Update — 2026-11-17

## Added to the main Automation Studio Android app

- Android NDK pinned to `28.2.13676358` (the default NDK listed for AGP 9.1.1).
- CMake pinned to `3.22.1`.
- `externalNativeBuild` wired to `app/src/main/cpp/CMakeLists.txt`.
- ARM ABI filters include `armeabi-v7a` (32-bit) and `arm64-v8a` (64-bit).
- Added a small C++20 JNI library and `NativeRuntimeBridge` smoke-check wrapper.
- CI installs Android SDK platform/build-tools, NDK and CMake before building the APK.
- App Builder generated projects that include C++ now also emit the NDK version and ARM ABI filters; their CI workflow installs NDK/CMake.
- App Builder Rust/JNI projects now generate a C++ JNI bridge, link the Rust `cdylib`, and include a CI cross-compile step for 32-bit and 64-bit ARM using `cargo-ndk`.
- Gradle memory settings are reduced to a 2 GiB heap and two workers to lower peak build pressure.

## Existing on-device compiler path

The project already contains `NativeCompilerRuntime`: it accepts a user-supplied Android/ARM64 Clang toolchain ZIP, checks for ARM64 ELF executables, and exposes C/C++ compile actions. No compiler executable is bundled in this update. The host NDK's Clang binaries are not Android/ARM64 app executables, so copying those binaries into the APK would not create a valid on-device compiler.

## Gradle Wrapper status

`gradle-wrapper.properties` now pins Gradle 9.3.1 and its official binary distribution SHA-256. The official Wrapper JAR and the `gradlew` / `gradlew.bat` launchers are still not present in this source ZIP because this build workspace has no network access and no Gradle installation. The GitHub Actions workflow now generates the official wrapper with Gradle 9.3.1, verifies its published SHA-256, and then builds through `./gradlew`. For a local checkout, run `scripts/generate-gradle-wrapper.sh` on a machine with Gradle 9.3.1 installed. Do not substitute a hand-written fake wrapper.

## Not bundled / still pending

- Android SDK/NDK/CMake packages are downloaded by CI or the user's Android build environment; they are not embedded in this ZIP.
- Android/ARM64 Clang toolchain ZIP for on-device compilation is not bundled.
- Rust compilation is configured for generated projects in GitHub Actions only; no Rust compiler is bundled for on-device use.
- Go, JavaScript/TypeScript and Python native compiler/runtime packages are not bundled by this update.
- A successful APK build and physical-device test have not been run in this workspace.

## Compatibility sources

- Android Gradle Plugin 9.1.1: Gradle 9.3.1, JDK 17, NDK 28.2.13676358.
- Android NDK/CMake are the official Android native build components.
- Gradle 9.3.1 distribution SHA-256 is pinned in `gradle-wrapper.properties`.
