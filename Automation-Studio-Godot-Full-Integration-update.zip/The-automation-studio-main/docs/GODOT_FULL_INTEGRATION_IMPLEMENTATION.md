# Automation Studio — Godot Runtime + Editor Build

## Included integration

- `org.godotengine:godot:4.7.2.stable` remains the default runtime AAR.
- `org.godotengine:godot-tools:4.7.2.stable` is selected for the editor-enabled build. Maven Central describes it as the Godot Engine Tools Android Library (Editor Build).
- `GodotRuntimeActivity` hosts the template runtime through `GodotFragment`.
- `GodotEditorActivity` hosts the editor-enabled build and adds the `--editor` command-line option.
- The IDE shows **Godot Editor** only in the editor-enabled APK; **Real Godot 3D** remains the runtime smoke-test entry.

## Build outputs

The included GitHub Actions workflow builds two APKs and uploads them together:

- `Automation-Studio-Godot-Runtime.apk` — template/runtime build.
- `Automation-Studio-Godot-Editor.apk` — editor-enabled build using the `godot-tools` AAR.

The Gradle switch is `-PgodotEditorBuild=true`. Without it, the regular runtime AAR is used. The two AARs are never included together, avoiding duplicate Godot classes and native libraries.

## Testing on device

1. Install the Runtime APK and open **Real Godot 3D** to test the bundled 3D smoke-test scene.
2. Install the Editor APK and open **Godot Editor**. The editor build is expected to enter Godot's editor mode/project manager.
3. Test project creation/opening and file access on-device. The Android editor is experimental and its UI is not fully touch-optimized; Godot recommends a hardware keyboard and mouse for a better experience.

## Important limitations

This integration provides a separate full-screen Godot editor surface hosted inside Automation Studio's Android app, not a custom-drawn Scene Tree/Inspector embedded into the existing Compose IDE panes. The first editor-enabled APK must be built and tested before claiming that the editor UI launches correctly in this host. It has not been built or run on a physical device in this patch-preparation environment.

Godot documents that only one engine instance is supported per process. Runtime and Editor are separate Activities but must not be launched simultaneously. Android editor project storage and file-picker behavior must be verified on the target Android version.
