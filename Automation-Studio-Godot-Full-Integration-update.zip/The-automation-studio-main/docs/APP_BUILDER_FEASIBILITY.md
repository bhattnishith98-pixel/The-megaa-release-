# App Builder Feasibility Study & Architecture Decision

## Evaluated Strategies
1. **Strategy 1 — Native Android Project Generator:** Emit Kotlin + Jetpack Compose + `AndroidManifest.xml` + Gradle files (`settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts`) and compile via Android SDK + Gradle.
2. **Strategy 2 — Packaged VM Runtime:** Embed `StudioVm` + verified `.stlc` bytecode inside a pre-built template APK.
3. **Strategy 3 — Hybrid (Selected & Implemented):**
   - **On-Device:** Visual multi-screen `AppDesign` validation (`AndroidManifest.xml`, reverse-DNS package ID, SDK range, Play-policy permission checks), automatic timestamped backups, line-by-line file diff preview, **Live Interactive VM App Runner** (executes UI widgets + StudioLang `onTapCode` handlers natively inside Automation Studio), and `.stla` / Gradle ZIP packaging with SHA-256 verification.
   - **External APK Compilation Boundary:** Full binary APK compilation (`javac`, `kotlinc`, `aapt2`, `d8`, `apksigner`, Gradle daemon) cannot execute legally and reliably inside an unrooted Android app sandbox without violating Google Play's Dynamic Code Loading policy or shipping a multi-hundred-MB JDK/SDK bundle. Automation Studio therefore generates a complete, build-ready Gradle + Jetpack Compose project ZIP exportable via SAF for building in Android Studio / CI, and never fakes an on-device APK build.
