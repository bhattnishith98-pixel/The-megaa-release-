# Native compiler and Godot runtime integration

## Real Godot 3D runtime

This revision adds the official Godot Android template library (`org.godotengine:godot:4.7.2.stable`) and a dedicated `GodotRuntimeActivity` hosted by `GodotFragment`. The embedded Godot project is in `app/src/main/assets/` (`project.godot`, `main.tscn`, and `scripts/runtime_demo.gd`). The `Real Godot 3D` action in the IDE opens this runtime. It is a real Godot 4.7.2 engine path, not the Kotlin 2D simulation in `GodotEngineKotlin.kt`.

The included scene is a small 3D smoke-test scene (camera, directional light, floor, rotating cube). It verifies engine startup and 3D rendering; it is not yet a full Godot editor UI. The Android library is the official MIT-licensed Godot artifact from Maven Central.

## On-device C/C++ compiler runtime

`NativeCompilerRuntime` adds a real process-based Clang launcher for Android ARM64 and a ZIP installer. The IDE's `Install C/C++` action imports a compatible toolchain archive. The archive must contain Android ARM64 ELF executables at `bin/clang` and `bin/clang++` plus any runtime libraries/headers the compiler needs. The installer checks ZIP paths, archive expansion limits, ELF64 format, and the AArch64 machine ID before activating it.

The compiler API exposes `compileC(context, projectRoot, source)` and `compileCpp(context, projectRoot, source)`. It invokes the compiler directly (no shell), confines source/output paths to the selected project, merges compiler output into `build/compiler-output.log`, and applies a 60-second process timeout.

**No compiler binary is bundled in this source ZIP.** The Android NDK's standard Clang executables are host binaries for Windows/macOS/Linux build machines, not Android/ARM64 app executables. A compatible Android/ARM64 toolchain archive is still required before C/C++ compilation can run on-device. This revision does not claim Java/Kotlin, Rust, Go, or other language toolchains are installed; those need their own Android-compatible compiler/runtime packages and adapters.

## Verification status

- Source integration and static file checks: performed.
- Android Gradle build: not run; this archive does not include a Gradle wrapper or configured Android SDK in this workspace.
- Godot device launch/render test: not run.
- C/C++ compile test: not run because no Android ARM64 Clang toolchain bundle is included.
