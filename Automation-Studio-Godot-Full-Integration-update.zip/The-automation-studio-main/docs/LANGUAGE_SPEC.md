# StudioLang (`.stl`) — Language Specification v1

## 1. Identity & Configuration
- **Language Name:** `StudioLang` (configured in `LanguageConfig.kt`)
- **File Extension:** `.stl`
- **Layout Sidecar:** `<name>.stl.layout.json`
- **Package Bundle:** `.stlpkg` (ZIP with `manifest.json`, `.stl` source, `.md` docs, SHA-256 digest)
- **Bytecode Magic / Version:** `0x53544C31` (`STL1`), format version `1`
- **Indentation:** Strictly 4 spaces per block level. Tab characters (`\t`) are rejected with `LEX001`.

## 2. Lexical Elements
- **Comments:** `# ...` to end of line.
- **Numbers:** Integers and floating-point (`42`, `3.14`).
- **Durations:** `<number>(ms|s|m|h)` (e.g., `500ms`, `2s`, `5m`, `1h`).
- **Text:** `"..."` or `'...'` with escapes `\n`, `\t`, `\\`, `\"`, `\'`.
- **Booleans / Null:** `true`, `false`, `none`.
- **Keywords (45):**
  `let`, `const`, `def`, `return`, `if`, `elif`, `else`, `for`, `in`, `while`, `repeat`, `times`, `break`, `continue`, `try`, `on`, `error`, `raise`, `retry`, `wait`, `timeout`, `use`, `as`, `needs`, `confirm`, `trigger`, `condition`, `constraint`, `action`, `block`, `macro`, `app`, `screen`, `source`, `when`, `emit`, `only`, `do`, `true`, `false`, `none`, `and`, `or`, `not`, `is`.

## 3. Types
`number`, `text`, `bool`, `list`, `map`, `none`, `time`, `duration`, `file`, `node`, `any`.

## 4. Operator Precedence (Lowest to Highest)
1. `or`
2. `and`
3. `not` (unary)
4. `==`, `!=`, `<`, `<=`, `>`, `>=`, `in`, `is`
5. `+`, `-`
6. `*`, `/`, `%`
7. `**` (right-associative)
8. Unary `-`
9. Call `(...)`, Member `.prop`, Index `[idx]`

## 5. EBNF Grammar
```ebnf
program        := { statement } EOF ;
statement      := use_stmt | needs_stmt | var_decl | assign_stmt
                | func_def | trigger_def | condition_def | constraint_def
                | action_def | block_def | macro_def | app_def | screen_def
                | if_stmt | for_stmt | while_stmt | repeat_stmt
                | break_stmt | continue_stmt | return_stmt
                | try_stmt | raise_stmt | retry_stmt | timeout_stmt
                | confirm_stmt | expr_stmt ;

use_stmt       := "use" IDENT { "." IDENT } [ "as" IDENT ] NEWLINE ;
needs_stmt     := "needs" IDENT { "," IDENT } NEWLINE ;
var_decl       := ( "let" | "const" ) IDENT [ ":" TYPE ] "=" expr NEWLINE ;
assign_stmt    := expr ( "=" | "+=" | "-=" | "*=" | "/=" ) expr NEWLINE ;

func_def       := "def" IDENT "(" [ param_list ] ")" [ "->" TYPE ] block_body ;
condition_def  := "condition" IDENT [ "(" [ param_list ] ")" ] [ "->" TYPE ] block_body ;
constraint_def := "constraint" IDENT [ "(" [ param_list ] ")" ] [ "->" TYPE ] block_body ;
action_def     := "action" IDENT [ "(" [ param_list ] ")" ] [ "->" TYPE ] block_body ;
block_def      := "block" IDENT [ "(" [ param_list ] ")" ] [ "->" TYPE ] block_body ;

trigger_def    := "trigger" IDENT ":" NEWLINE INDENT
                  { needs_stmt | "source" expr NEWLINE | "when" expr NEWLINE | "emit" expr NEWLINE | statement }
                  DEDENT ;

macro_def      := "macro" IDENT ":" NEWLINE INDENT
                  { needs_stmt | "on" expr NEWLINE | "only" "if" expr NEWLINE | "do" block_body | "on" "error" [ IDENT ] block_body }
                  DEDENT ;

if_stmt        := "if" expr block_body { "elif" expr block_body } [ "else" block_body ] ;
for_stmt       := "for" IDENT "in" expr block_body ;
while_stmt     := "while" expr block_body ;
repeat_stmt    := "repeat" expr "times" block_body ;
try_stmt       := "try" block_body "on" "error" [ IDENT ] block_body ;
retry_stmt     := "retry" expr "times" [ "," "wait" expr ] block_body ;
timeout_stmt   := "timeout" expr block_body ;
confirm_stmt   := "confirm" expr NEWLINE ;
block_body     := ":" NEWLINE INDENT { statement } DEDENT ;
```
