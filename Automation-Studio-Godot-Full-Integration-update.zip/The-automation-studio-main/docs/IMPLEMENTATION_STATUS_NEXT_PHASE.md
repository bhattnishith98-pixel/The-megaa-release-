# Automation Studio — implementation status and next phase

## Implemented in this revision

- The Repositories pane now presents one fixed import mode: **Full Source + Compile**.
- The ZIP importer no longer truncates imports at 2,000 files (or at the old default index count).
- Full imports extract all archive entries, including binary assets, into the selected repository folder.
- Supported text files up to 96 KiB are indexed for the IDE. Larger text files and binary assets are retained on disk but are not loaded into the in-memory editor model.
- Repository rescanning no longer skips `node_modules` or `build` directories.
- Existing GitHub download and Android Storage Access Framework ZIP upload flows remain in place.
- Zip-Slip checks remain enabled. Expanded ZIP data is guarded at 512 MiB per entry and 4 GiB per archive to reduce ZIP-bomb/storage-exhaustion risk.

## Added in this revision

1. **Real Godot Android runtime integration:** adds the official `org.godotengine:godot:4.7.2.stable` Android library, a `GodotRuntimeActivity` hosted by `GodotFragment`, and an embedded Godot 4.7 3D smoke-test project in `app/src/main/assets/`. The IDE has a `Real Godot 3D` action. This launches the real Godot engine runtime and renderer, separate from the previous Kotlin 2D simulation.
2. **C/C++ native compiler integration layer:** adds an Android ARM64 Clang toolchain ZIP installer, architecture/path/size validation, C17 and C++20 compile adapters, bounded process execution, and IDE controls to install Clang and compile the active C/C++ source file.
3. **Android NDK/CMake build path:** the app now builds a C++20 JNI smoke-test library for ARM 32-bit and 64-bit targets. App Builder C++ projects emit NDK/CMake settings. Generated Rust/JNI projects also emit a Rust cdylib + C++ JNI bridge and a `cargo-ndk` GitHub Actions cross-build path.

## Still required before these features are fully operational

1. **Clang toolchain payload:** no Android/ARM64 compiler binaries are bundled in the source ZIP. The user must supply a compatible toolchain ZIP containing `bin/clang`, `bin/clang++`, and all required runtime libraries/headers. Host-platform NDK executables cannot be copied and run directly on Android. Until a compatible payload is installed, the compiler UI correctly reports that the toolchain is missing.
2. **Other native language compilers:** generated Rust/JNI projects now have a GitHub Actions cross-compilation route for ARM 32-bit and 64-bit. A Rust compiler is not bundled for on-device use. Go and other language toolchains/runtime adapters are still pending. Java/Kotlin source compilation remains part of the Android Gradle build rather than a standalone in-app compiler.
3. **Godot editor and export pipeline:** the embedded engine is a real 3D runtime, not the full Godot editor UI. Editor integration, project import, export templates, and Gradle export automation remain separate work.
4. **Device/build verification:** static checks were run for the workflow YAML and C++ JNI source. An Android Gradle build and physical-device runtime test were not possible in this workspace. The source archive still does not contain the Wrapper JAR or launcher scripts; CI generates and checksum-verifies the official Wrapper before building. The Godot engine launch and on-device Clang process must be validated on the target Android device.
5. **One canonical project filesystem/root agent and Google AI Studio/Gemini:** these remain unimplemented and are outside this runtime/compiler change.

## Technical basis

Godot officially distributes an Android library AAR and documents embedding it in an existing Android app with `GodotHost`/`GodotFragment`. The Android NDK's regular Clang binaries are host tools; the on-device compiler integration therefore accepts a separate Android/ARM64 executable toolchain bundle rather than pretending a desktop NDK binary will run on a phone.
