# External Repositories & Bridges Setup (`external_repos/`)

Automation Studio includes **ready-made Kotlin/Compose workflows and live runtime bridges** for all three open-source ecosystems so the app runs 100% offline with zero heavy startup downloads:

1. **Visual Studio Code** (`microsoft/vscode`, MIT) -> Multi-tab editor, Activity Rail, Explorer, Global Search, Problems, Extensions/Themes, Command Palette, Integrated Terminal.
2. **Godot Engine** (`godotengine/godot`, MIT) -> Scene Tree, 2D Viewport Canvas + Gizmos, PhysicsServer2D AABB step loop, `.tscn` serializer, and 7-language `Attach Script` -> `StudioVm`.
3. **Android Code Studio** (`AndroidCSOfficial/android-code-studio`, MIT/GPL-3.0 Ecosystem) -> App Override Mode, Live Compose & XML UI Preview/Tester, Manifest Play-Policy Audit, Logcat, and Gradle APK CI ZIP Export.

---

## Option A — 1-Tap GitHub `.zip` Fetch Inside the App (Recommended)
Inside **Automation Studio -> IDE -> Repos Rail Tab**:
1. Tap **Fetch GitHub** on any repository card:
   - `godot-master.zip` (~80 MB) — `https://github.com/godotengine/godot/archive/refs/heads/master.zip`
   - `android-code-studio-main.zip` (~80 MB) — `https://github.com/AndroidCSOfficial/android-code-studio/archive/refs/heads/main.zip`
   - `vscode-main.zip` — `https://github.com/microsoft/vscode/archive/refs/heads/main.zip`
2. Or tap **Import ZIP** / **Mount .ZIP** to load a `.zip` already downloaded onto your phone storage (uses zero-permission Android SAF `OpenDocument`).
3. The fixed **Full Source + Compile** mode extracts every file in the ZIP archive into `external_repos/` (including non-text assets) with Zip-Slip traversal protection. Supported text files up to 96 KiB are indexed into the IDE's in-memory file model; larger text files and binary assets remain on disk but are not currently editor-indexed. There is no arbitrary file-count cap. A safety guard currently stops an archive if expanded content exceeds 512 MiB for one entry or 4 GiB total; actual available device storage may impose a lower practical limit.

---

## Option B — Pre-Bundle ZIPs (`assets/repos/`) or Clone Locally When Exporting
1. To pre-bundle repository archives inside a custom local APK build without bloating the default template, place the downloaded archives at:
   - `app/src/main/assets/repos/godot-master.zip`
   - `app/src/main/assets/repos/android-code-studio-main.zip`
   - `app/src/main/assets/repos/vscode-main.zip`
   Automation Studio automatically scans `assets/repos/*.zip` on startup via `ExternalRepoBridgeEngine.scanBundledAssetZips(...)` and mounts them cleanly.
2. Or clone full upstream repositories under:

```text
external_repos/
├── vscode/               # git clone https://github.com/microsoft/vscode external_repos/vscode
├── godot/                # git clone https://github.com/godotengine/godot external_repos/godot
└── android-code-studio/  # git clone https://github.com/AndroidCSOfficial/android-code-studio external_repos/android-code-studio
```

Note: Giant desktop C++/Electron/APK trees are intentionally not baked directly into the default APK binary so installation stays fast and compliant with Google Play Developer Policy (which prohibits runtime dynamic `.dex`/`.jar`/`.so` code loading). Automation Studio bridges all mounted source files safely through `ExternalRepoBridgeEngine` + `UnifiedIdeController` + `StudioVm`.


## Important runtime/compiler boundary

Mounting upstream source is **not** the same as building or embedding the upstream applications. The current Kotlin bridge/editor implementations do not turn the imported VS Code repository into the real VS Code desktop runtime, and the current Godot Kotlin model is not the native Godot Engine (no full Godot 3D renderer/editor/runtime). The app does not yet ship separate on-device C/C++/Java/Kotlin/GDScript/TypeScript compilers for these repositories. A real compiler toolchain needs a separately built and legally distributable Android/ARM64 toolchain (or a secure remote build service), language-specific process/runtime integration, resource management, and end-to-end device tests.

Google AI Studio is also not embedded by this import change. A proper Gemini connection requires a user-provided API key, secure key storage, model/API configuration, network error handling, and clear usage/cost controls. Do not put a private API key directly in the APK source or commit it to the repository.
