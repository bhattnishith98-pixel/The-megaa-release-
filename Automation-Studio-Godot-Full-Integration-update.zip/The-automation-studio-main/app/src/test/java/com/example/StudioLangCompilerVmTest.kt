package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.docs.ExamplesLibrary
import com.example.lang.*
import com.example.runtime.CredentialVault
import com.example.runtime.StudioStdLib
import com.example.vm.*
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StudioLangCompilerVmTest {

    private fun newRuntime(): Triple<StudioCompiler, CapabilityManager, StudioStdLib> {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "test_ws_${System.nanoTime()}").apply { mkdirs() }
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val std = StudioStdLib(ctx, ws, CredentialVault(ctx))
        return Triple(StudioCompiler(), caps, std)
    }

    @Test
    fun lexer_rejects_tabs_and_tracks_indent_dedent() {
        val bad = StudioLexer("if true:\n\tlog.info(\"tab\")").tokenize()
        assertTrue(bad.diagnostics.any { it.code == "LEX001" })

        val good = StudioLexer("if true:\n    let x = 5s\nlog.info(x)").tokenize()
        assertFalse(good.diagnostics.any { it.severity == DiagnosticSeverity.ERROR })
        assertTrue(good.tokens.any { it.type == TokenType.INDENT })
        assertTrue(good.tokens.any { it.type == TokenType.DEDENT })
        assertTrue(good.tokens.any { it.type == TokenType.DURATION && it.literal == 5000L })
    }

    @Test
    fun analyzer_blocks_const_reassignment_and_outside_break() {
        val compiler = StudioCompiler()
        val res1 = compiler.compile("const PI = 3\nPI = 4")
        assertFalse(res1.success)
        assertTrue(res1.diagnostics.any { it.code == "SEM003" })

        val res2 = compiler.compile("break")
        assertFalse(res2.success)
        assertTrue(res2.diagnostics.any { it.code == "SEM005" })
    }

    @Test
    fun ir_optimizer_folds_constants_and_eliminates_dead_code() {
        val compiler = StudioCompiler()
        val out = compiler.compile("let x = 2 + 3 * 4\nreturn x\nlet dead = 99")
        assertTrue(out.success)
        assertNotNull(out.irStats)
        assertTrue(out.irStats!!.foldedConstants >= 1)
        assertTrue(out.irStats!!.deadOpsEliminated >= 1)
    }

    @Test
    fun bytecode_verifier_rejects_unlisted_host_api_and_bad_magic() {
        val badMagic = CompiledBytecode(
            magic = 0x12345678,
            constPool = emptyList(),
            functions = emptyList(),
            macros = emptyList(),
            triggers = emptyList(),
            requiredCapabilities = emptySet(),
            instructions = intArrayOf(Opcode.pack(Opcode.RETURN)),
            lineTable = intArrayOf(1)
        )
        assertFalse(BytecodeVerifier.verify(badMagic).isValid)

        val unlistedApi = CompiledBytecode(
            constPool = listOf(TextVal("evil.exec_shell")),
            functions = listOf(
                FunctionBytecodeMeta(0, "__main__", CallableKind.MAIN, 0, 2, 0, 1, listOf("a"), emptySet())
            ),
            macros = emptyList(),
            triggers = emptyList(),
            requiredCapabilities = emptySet(),
            instructions = intArrayOf(
                Opcode.pack(Opcode.CALL_HOST, 0, 0),
                Opcode.pack(Opcode.RETURN)
            ),
            lineTable = intArrayOf(1, 1)
        )
        val ver = BytecodeVerifier.verify(unlistedApi)
        assertFalse(ver.isValid)
        assertTrue(ver.diagnostics.any { it.code == "VER010" })
    }

    @Test
    fun bytecode_binary_roundtrip_preserves_execution() = runTest {
        val (compiler, caps, std) = newRuntime()
        val compiled = compiler.compile("let a = 6\nlet b = 7\nreturn a * b")
        assertTrue(compiled.success)
        val bytes = compiled.bytecode!!.encodeToBytes()
        val decoded = CompiledBytecode.decodeFromBytes(bytes)
        val res = StudioVm(caps, std).execute(decoded)
        assertTrue(res.success)
        assertEquals(NumVal(42.0), res.returnValue)
    }

    @Test
    fun security_sandbox_enforces_capabilities_path_traversal_and_confirm() = runTest {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "sec_ws_${System.nanoTime()}").apply { mkdirs() }
        val caps = CapabilityManager(emptySet()) // Nothing granted!
        val std = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val compiler = StudioCompiler()

        val capTest = compiler.compile("needs FILE_ACCESS\nfiles.write(\"a.txt\", \"hi\")")
        assertTrue(capTest.success)
        val deniedRes = StudioVm(caps, std).execute(capTest.bytecode!!)
        assertFalse(deniedRes.success)
        assertTrue(deniedRes.error?.contains("FILE_ACCESS") == true)

        caps.grant(StudioCapability.FILE_ACCESS)
        val travTest = compiler.compile("needs FILE_ACCESS\nfiles.read(\"../../etc/passwd\")")
        val travRes = StudioVm(caps, std).execute(travTest.bytecode!!)
        assertFalse(travRes.success)
        assertTrue(travRes.error?.contains("Path traversal") == true)

        val confirmTest = compiler.compile("confirm \"Delete?\"\nreturn 1")
        val declineDebugger = object : ExecutionDebugger {
            override suspend fun onStep(pc: Int, line: Int, funcName: String, localsSnapshot: Map<String, String>) {}
            override suspend fun requestConfirm(prompt: String): Boolean = false
        }
        val declinedRes = StudioVm(caps, std).execute(compiler.compile("confirm \"Delete?\"\nreturn 1").bytecode!!, debugger = declineDebugger)
        assertFalse(declinedRes.success)
        assertTrue(declinedRes.error?.contains("cancelled") == true)

        caps.grant(StudioCapability.NOTIFICATIONS)
        val notifDenied = StudioVm(caps, std).execute(compiler.compile("needs NOTIFICATIONS\nnotify.show(\"T\", \"B\")").bytecode!!)
        assertFalse(notifDenied.success)
        assertTrue(notifDenied.error?.contains("POST_NOTIFICATIONS") == true)
    }

    @Test
    fun vm_enforces_instruction_budget_on_infinite_loop() = runTest {
        val (compiler, caps, std) = newRuntime()
        val out = compiler.compile("while true:\n    let x = 1")
        assertTrue(out.success)
        val res = StudioVm(caps, std, ExecutionPolicy(maxInstructions = 500)).execute(out.bytecode!!)
        assertFalse(res.success)
        assertTrue(res.error?.contains("Instruction budget") == true)
    }

    @Test
    fun all_52_examples_compile_and_execute_cleanly() = runTest {
        val app = ApplicationProvider.getApplicationContext<Application>()
        Shadows.shadowOf(app).grantPermissions(Manifest.permission.POST_NOTIFICATIONS)
        val (compiler, caps, std) = newRuntime()
        assertTrue("Expected >= 50 examples", ExamplesLibrary.examples.size >= 50)
        val vm = StudioVm(caps, std)
        for (ex in ExamplesLibrary.examples) {
            val comp = compiler.compile(ex.code)
            assertTrue("Example ${ex.id} (${ex.title}) failed compile: ${comp.diagnostics}", comp.success)
            val bc = comp.bytecode!!
            val entry = bc.macros.firstOrNull()?.doFuncIndex ?: 0
            val args = if (entry != 0) listOf(MapVal()) else emptyList()
            val res = vm.execute(bc, entry, args)
            // ex48 intentionally raises & catches via macro on error
            if (ex.id != "ex48") {
                assertTrue("Example ${ex.id} (${ex.title}) failed VM: ${res.error}", res.success)
            }
        }
    }

    @Test
    fun benchmark_suite_produces_positive_measured_metrics() = runTest {
        val (compiler, caps, std) = newRuntime()
        val report = BenchmarkSuite.runAll(compiler, caps, std)
        println(
            "BENCHMARK_JVM: coldCompileUs=${report.coldCompileUs}, cachedCompileUs=${report.cachedCompileUs}, " +
                "irOps=${report.originalIrOps}->${report.optimizedIrOps} (folded=${report.foldedConstants}), " +
                "vmLoopMs=${report.vmLoopMs}, vmOps=${report.vmInstructionsExecuted}, ips=${report.instructionsPerSecond}, " +
                "graph1000Ms=${report.largeGraphCodegenMs}, heapDeltaKb=${report.heapDeltaKb}"
        )
        assertTrue(report.coldCompileUs > 0)
        assertEquals(1000, report.largeGraphNodesCount)
        assertTrue(report.vmInstructionsExecuted > 2000)
    }
}
