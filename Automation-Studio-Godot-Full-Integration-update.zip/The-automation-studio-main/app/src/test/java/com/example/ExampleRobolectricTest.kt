package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.runtime.CredentialVault
import com.example.vm.RuntimeIdentity
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun app_name_and_runtime_identity_are_configured() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Automation Studio", context.getString(R.string.app_name))
        val idReport = RuntimeIdentity.verifyAppIdentity(context)
        assertTrue(idReport.isExclusiveSessionValid)
    }

    @Test
    fun credential_vault_stores_reads_and_deletes_securely() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val vault = CredentialVault(context)
        vault.storeSecret("ci_token", "super_secret_987")
        assertEquals("super_secret_987", vault.getSecret("ci_token"))
        assertTrue("ci_token" in vault.listKeys())
        assertTrue(vault.deleteSecret("ci_token"))
        assertNull(vault.getSecret("ci_token"))
    }

    @Test
    fun navigation_tabs_and_studio_ui_render_cleanly() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("hero_open_nodes_button").assertIsDisplayed()
        composeRule.onNodeWithTag("nav_nodes").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("run_vm_button").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_agent").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("agent_emergency_stop").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_apps").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("build_app_project_button").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_docs").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("docs_search_input").assertIsDisplayed()
    }

    @Test
    fun edit_macro_opens_full_text_mode_with_quickstart_and_app_wizard_picker() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("studio_dashboard_list")
            .performScrollToNode(hasTestTag("edit_macro_macro_workspace_note"))
        composeRule.onNodeWithTag("edit_macro_macro_workspace_note")
            .performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("studio_code_editor").assertIsDisplayed()
        composeRule.onNodeWithTag("save_macro_button").assertIsDisplayed()

        composeRule.onNodeWithTag("mode_node").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("node_quickstart_card").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_apps").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("app_wizard_card").assertIsDisplayed()
        composeRule.onNodeWithTag("wizard_wire_button_chip")
            .performScrollTo()
            .performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("element_label_input").assertExists()
        composeRule.onNodeWithTag("block_to_button_picker")
            .performScrollTo()
            .assertIsDisplayed()
    }
}
