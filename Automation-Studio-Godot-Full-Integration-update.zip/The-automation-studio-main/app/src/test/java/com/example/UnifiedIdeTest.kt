package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.compose.ui.test.performTextReplacement
import androidx.test.core.app.ApplicationProvider
import com.example.agent.AiProviderKind
import com.example.agent.MultiProviderAgentAi
import com.example.appbuilder.AndroidProjectGenerator
import com.example.appbuilder.AppBuildLanguage
import com.example.appbuilder.AppDesign
import com.example.ide.*
import com.example.lang.StudioCapability
import com.example.runtime.CredentialVault
import com.example.services.StudioAccessibilityService
import com.example.ui.screens.AiStudioWebPortals
import com.example.runtime.StudioStdLib
import com.example.vm.CapabilityManager
import com.example.vm.StudioCompiler
import com.example.vm.StudioVm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UnifiedIdeTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun all_seven_polyglot_languages_compile_and_execute_godot_and_voice_calls() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_polyglot_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val spoken = mutableListOf<String>()
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx), voiceSpeakCallback = { spoken += it })

        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign(),
            voiceSpeakCallback = { spoken += it }
        )

        ScriptLanguage.entries.forEach { lang ->
            val starter = PolyglotGodotCompiler.starterScript(
                language = lang,
                nodeType = GodotNodeType.CHARACTER_BODY_2D,
                templateKind = ScriptTemplateKind.VOICE_REACTIVE,
                nodeName = "Player"
            )
            val (comp, stl) = PolyglotGodotCompiler.compileForExecution(
                language = lang,
                source = starter,
                targetNodeName = "Player",
                invokeProcessTick = false,
                compiler = compiler
            )
            assertTrue("Expected ${lang.label} to compile cleanly. Diags=${comp.diagnostics}\nSTL:\n$stl", comp.success)
            assertNotNull(comp.bytecode)

            runBlocking {
                val res = StudioVm(caps, stdLib).execute(comp.bytecode!!)
                assertTrue("Expected ${lang.label} VM execution success: ${res.error}", res.success)
            }
        }
        assertTrue("Expected voice.speak calls from polyglot Godot scripts", spoken.isNotEmpty())
        ctrl.stopScene()
    }

    @Test
    fun attach_script_to_godot_node_and_live_physics_and_touchzone_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_attach_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))

        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )

        val spawned = ctrl.addSceneNode(GodotNodeType.SPRITE_2D, "RocketBoss", 260f, 110f)
        val attachedFile = ctrl.attachScriptToNode(spawned.id, ScriptLanguage.KOTLIN, ScriptTemplateKind.MOVEMENT)
        assertNotNull(attachedFile)
        assertEquals("scripts/rocketboss_script.kt", attachedFile!!.path)
        assertEquals(attachedFile.path, ctrl.activeTabPath.value)
        assertTrue(attachedFile.path in ctrl.openTabs.value)

        // Verify .tscn updated
        val tscn = ctrl.files.value.first { it.path == "scenes/main.tscn" }.content
        assertTrue(tscn.contains("[node name=\"RocketBoss\" type=\"Sprite2D\""))
        assertTrue(tscn.contains("scripts/rocketboss_script.kt"))

        // Verify Player moves during Godot tick & TouchZone triggers jump impulse
        val startX = ctrl.sceneNodes.value.first { it.name == "Player" }.x
        val startY = ctrl.sceneNodes.value.first { it.name == "Player" }.y
        ctrl.stepSceneTick()
        Thread.sleep(60)
        ctrl.triggerTouchZone("node_touch")
        Thread.sleep(60)
        val afterPlayer = ctrl.sceneNodes.value.first { it.name == "Player" }
        assertTrue("Player should move along X from attached script or TouchZone Y impulse", afterPlayer.x != startX || afterPlayer.y != startY)
        ctrl.stopScene()
    }

    @Test
    fun terminal_voice_hindi_english_and_android_xml_preview_and_zip_export_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_acs_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val spoken = mutableListOf<String>()
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx), voiceSpeakCallback = { spoken += it })

        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign(),
            voiceSpeakCallback = { spoken += it }
        )

        val spawnMsg = ctrl.executeTerminalCommand("godot spawn Sprite2D TerminalEnemy")
        assertTrue(spawnMsg.contains("TerminalEnemy"))
        assertTrue(ctrl.sceneNodes.value.any { it.name == "TerminalEnemy" })

        val catOut = ctrl.executeTerminalCommand("cat scenes/main.tscn")
        assertTrue(catOut.contains("[gd_scene"))

        // Hindi voice commands work
        ctrl.handleVoiceCommand("एंड्राइड मोड")
        ctrl.handleVoiceCommand("android mode")
        assertEquals(IdeWorkspaceMode.ANDROID_CODE_STUDIO, ctrl.workspaceMode.value)

        // Android XML layout parses cleanly into live preview widgets
        val xmlContent = ctrl.files.value.first { it.path.endsWith("activity_main.xml") }.content
        val xmlWidgets = PolyglotGodotCompiler.parseComposeWidgetsForPreview(xmlContent, AppDesign())
        assertTrue(xmlWidgets.any { it.kind == "BUTTON" && it.label == "Run Android Action" })
        assertTrue(xmlWidgets.any { it.kind == "SWITCH" })

        // Manifest audit Play Policy check
        ctrl.createOrUpdateFile(
            "android/app/src/main/AndroidManifest.xml",
            """<manifest package="com.example.app"><uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/><application/></manifest>"""
        )
        val diags = ctrl.runCompileAndTestSync()
        assertTrue(diags.any { it.message.contains("Play Policy") })

        // Export real Android Gradle ZIP
        val outDir = File(ws, "out_app").apply { mkdirs() }
        val backupsDir = File(ws, "backups").apply { mkdirs() }
        val mergedDesign = ctrl.applyAppDesignSnapshot(AppDesign())
        val buildOut = AndroidProjectGenerator.buildAndExport(mergedDesign, outDir, backupsDir, null)
        assertTrue(buildOut.success)
        assertNotNull(buildOut.zipBytes)
        assertTrue(buildOut.zipBytes!!.isNotEmpty())
        ctrl.stopScene()
    }

    @Test
    @Config(sdk = [36], qualifiers = "w840dp-h412dp-land")
    fun full_end_to_end_landscape_tri_pane_workflow_runs_cleanly_in_ui() {
        composeRule.waitForIdle()
        // Launch from Dashboard hero button
        composeRule.onNodeWithTag("hero_open_ide_button").performClick()
        composeRule.waitForIdle()

        // Verify all 3 panes are displayed together in Landscape
        composeRule.onNodeWithTag("unified_ide_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("scene_node_item_Player").assertIsDisplayed()
        composeRule.onNodeWithTag("vscode_code_editor").assertIsDisplayed()
        composeRule.onNodeWithTag("godot_2d_canvas").assertIsDisplayed()

        // 1. Add Godot node via UI dialog
        composeRule.onNodeWithTag("add_godot_node_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("add_node_name_input").performTextReplacement("BossEnemy")
        composeRule.onNodeWithTag("confirm_add_node_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("scene_tree_list").performScrollToNode(hasTestTag("scene_node_item_BossEnemy"))
        composeRule.onNodeWithTag("scene_node_item_BossEnemy").assertIsDisplayed()

        // 2. Attach Python script to BossEnemy and open in VS Code Editor
        composeRule.onNodeWithTag("attach_script_node_BossEnemy").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("attach_lang_python").performClick()
        composeRule.onNodeWithTag("confirm_attach_script_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_tab_bossenemy_script.py").assertIsDisplayed()

        // 3. Test Godot transport controls (Play -> Advance -> Stop -> Step)
        composeRule.mainClock.autoAdvance = false
        composeRule.onNodeWithTag("godot_play_pause_btn").performClick()
        composeRule.mainClock.advanceTimeBy(120L)
        composeRule.onNodeWithTag("godot_stop_btn").performClick()
        composeRule.mainClock.autoAdvance = true
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("godot_step_btn").performClick()
        composeRule.waitForIdle()

        // 4. Test VS Code Terminal REPL & Bottom Tabs
        composeRule.onNodeWithTag("ide_terminal_input").performTextInput("ls")
        composeRule.onNodeWithTag("ide_terminal_send").performClick()
        composeRule.onNodeWithTag("bottom_tab_problems").performClick()
        composeRule.onNodeWithTag("bottom_tab_logcat").performClick()
        composeRule.onNodeWithTag("bottom_tab_terminal").performClick()
        composeRule.waitForIdle()

        // 5. Test VS Code Activity Rail tabs (Explorer, Search, Extensions Theme, Voice)
        composeRule.onNodeWithTag("activity_tab_extensions").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("theme_chip_vs_dark_plus").performClick()
        composeRule.onNodeWithTag("activity_tab_search").performClick()
        composeRule.onNodeWithTag("ide_search_input").performTextInput("Player")
        composeRule.onNodeWithTag("activity_tab_voice_ai").performClick()
        composeRule.waitForIdle()

        // 6. Test Command Palette & MIT Licenses dialogs
        composeRule.onNodeWithTag("ide_palette_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("command_palette_search").assertIsDisplayed()
        composeRule.onNodeWithText("Close").performClick()

        composeRule.onNodeWithTag("ide_licenses_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Done").performClick()

        // 7. Switch to Android Code Studio Override, test live UI preview & Verify & Export ZIP
        composeRule.onNodeWithTag("mode_acs_chip").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("acs_live_preview_card").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Increment Counter").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithText("Live Interactive App Preview (Events: 1)", substring = true).performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("acs_actions_row").performScrollTo().performScrollToNode(hasTestTag("acs_run_test_btn"))
        composeRule.onNodeWithTag("acs_run_test_btn").performClick()
        composeRule.onNodeWithTag("acs_actions_row").performScrollToNode(hasTestTag("acs_export_zip_btn"))
        composeRule.onNodeWithTag("acs_export_zip_btn").performClick()
        composeRule.waitForIdle()

        // 8. Switch to Repos & Bridges Rail Tab and verify all 3 repository cards + Fetch GitHub + bridge workflows
        composeRule.onNodeWithTag("activity_tab_repos_bridges").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("mount_repo_zip_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("repos_bridges_list").performScrollToNode(hasTestTag("fetch_github_zip_godot"))
        composeRule.onNodeWithTag("fetch_github_zip_godot").assertIsDisplayed()
        composeRule.onNodeWithTag("repos_bridges_list").performScrollToNode(hasTestTag("fetch_github_zip_android-code-studio"))
        composeRule.onNodeWithTag("fetch_github_zip_android-code-studio").assertIsDisplayed()
        composeRule.onNodeWithTag("repos_bridges_list").performScrollToNode(hasTestTag("run_bridge_bridge_vscode_to_godot"))
        composeRule.onNodeWithTag("run_bridge_bridge_vscode_to_godot").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("repos_bridges_list").performScrollToNode(hasTestTag("run_bridge_bridge_acs_android_pipeline"))
        composeRule.onNodeWithTag("run_bridge_bridge_acs_android_pipeline").performClick()
        composeRule.waitForIdle()

        // 9. Verify VS Code Outline, Git SCM, Find/Replace, Split Editor, Breadcrumbs, Comment/Format, Status Bar, Undo/Redo, and ACS Widget Designer
        composeRule.onNodeWithTag("vscode_breadcrumbs").assertIsDisplayed()
        composeRule.onNodeWithTag("vscode_status_bar").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_comment_btn").performClick()
        composeRule.onNodeWithTag("editor_comment_btn").performClick()
        composeRule.onNodeWithTag("editor_format_btn").performClick()
        composeRule.onNodeWithTag("editor_wrap_toggle").performClick()
        composeRule.onNodeWithTag("editor_split_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("vscode_split_right_pane").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_split_btn").performClick()

        composeRule.onNodeWithTag("activity_tab_outline").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("activity_tab_source_control").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("git_commit_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_find_toggle_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_find_input").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_undo_btn").performClick()
        composeRule.onNodeWithTag("acs_actions_row").performScrollTo().performScrollToNode(hasTestTag("acs_fix_imports_btn"))
        composeRule.onNodeWithTag("acs_fix_imports_btn").performClick()
        composeRule.onNodeWithTag("acs_add_widget_button").performScrollTo().performClick()
        composeRule.onNodeWithTag("acs_create_vector_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
    }

    @Test
    fun upstream_three_repo_zip_and_folder_mount_with_bridges_and_zip_slip_protection_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_repos_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )

        // 1. Mount VS Code ZIP
        val vscodeZip = buildZipBytes(
            "vscode-main/package.json" to "{\"name\":\"code-oss-dev\"}",
            "vscode-main/src/vs/editor/browser/editorBrowser.ts" to "export interface ICodeEditor { getValue(): string; }",
            "vscode-main/src/vs/workbench/workbench.desktop.main.ts" to "export class WorkbenchShell {}"
        )
        val vsRes = ctrl.mountRepoFromZipStreamSync(null, "vscode-main.zip", ByteArrayInputStream(vscodeZip))
        assertEquals(UpstreamRepoKind.VSCODE, vsRes.status.kind)
        assertEquals(RepoMountState.USER_REPO_MOUNTED, vsRes.status.state)
        assertTrue(vsRes.status.detectedLayers.contains("src/vs/editor"))
        assertTrue(vsRes.status.detectedLayers.contains("src/vs/workbench"))

        // 2. Mount Godot ZIP
        val godotZip = buildZipBytes(
            "godot-master/SConstruct" to "env = Environment()",
            "godot-master/core/object/object.h" to "class Object {};",
            "godot-master/scene/2d/node_2d.h" to "class Node2D {};",
            "godot-master/modules/gdscript/gdscript_vm.cpp" to "// GDScript VM"
        )
        val gdRes = ctrl.mountRepoFromZipStreamSync(null, "godot-master.zip", ByteArrayInputStream(godotZip))
        assertEquals(UpstreamRepoKind.GODOT, gdRes.status.kind)
        assertTrue(gdRes.status.detectedLayers.contains("core"))
        assertTrue(gdRes.status.detectedLayers.contains("modules/gdscript"))

        // 3. Mount Android Code Studio ZIP
        val acsZip = buildZipBytes(
            "android-code-studio-main/settings.gradle.kts" to "include(\":app\", \":xml-inflater\")",
            "android-code-studio-main/app/src/main/java/com/tom/rv2ide/Main.kt" to "package com.tom.rv2ide",
            "android-code-studio-main/xml-inflater/src/main/java/Inflater.kt" to "class XmlInflater {}"
        )
        val acsRes = ctrl.mountRepoFromZipStreamSync(null, "android-code-studio-main.zip", ByteArrayInputStream(acsZip))
        assertEquals(UpstreamRepoKind.ANDROID_CODE_STUDIO, acsRes.status.kind)
        assertTrue(acsRes.status.detectedLayers.contains("xml-inflater"))

        // 4. Open mounted repo file & check terminal `repos` / `bridges`
        assertTrue(ctrl.openMountedSampleFile(UpstreamRepoKind.VSCODE))
        val reposOut = ctrl.executeTerminalCommand("repos")
        assertTrue(reposOut.contains("Repo Mounted"))

        // 5. Execute all 3 cross-repo workflow bridges
        val b1 = ctrl.runBridgeWorkflowSync("bridge_vscode_to_godot")
        val b2 = ctrl.runBridgeWorkflowSync("bridge_godot_servers_vm")
        val b3 = ctrl.runBridgeWorkflowSync("bridge_acs_android_pipeline")
        assertTrue(b1.startsWith("PASS"))
        assertTrue(b2.startsWith("PASS"))
        assertTrue(b3.startsWith("PASS"))

        // 6. Verify Zip-Slip path traversal protection
        val maliciousZip = buildZipBytes("../../evil_escape.txt" to "malicious")
        val blocked = try {
            ctrl.mountRepoFromZipStreamSync(UpstreamRepoKind.VSCODE, "evil.zip", ByteArrayInputStream(maliciousZip))
            false
        } catch (e: SecurityException) {
            true
        }
        assertTrue("Zip-Slip traversal entry must be blocked", blocked)
        ctrl.stopScene()
    }

    @Test
    fun vscode_git_outline_undo_and_acs_designer_asset_studio_and_godot_timer_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_adv_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )

        // 1. VS Code Undo / Redo + Find & Replace + Code Outline
        assertTrue(ctrl.openFile("scripts/player_controller.gd"))
        val original = ctrl.files.value.first { it.path == "scripts/player_controller.gd" }.content
        ctrl.updateActiveFileContent("$original\n# edited line")
        assertTrue(ctrl.undoActiveFile())
        assertEquals(original, ctrl.files.value.first { it.path == "scripts/player_controller.gd" }.content)
        assertTrue(ctrl.redoActiveFile())
        assertTrue(ctrl.files.value.first { it.path == "scripts/player_controller.gd" }.content.contains("# edited line"))

        val replacedCount = ctrl.findAndReplaceActiveFile("edited line", "replaced marker", true)
        assertEquals(1, replacedCount)

        val symbols = IdeAdvancedModulesEngine.extractCodeOutline(
            ctrl.files.value.first { it.path == "scripts/player_controller.gd" }
        )
        assertTrue(symbols.any { it.name.contains("_ready") || it.name.contains("_process") })

        // 2. Git SCM Diff, Revert, Commit
        assertTrue(ctrl.gitChanges.value.any { it.path == "scripts/player_controller.gd" && it.status == "M" })
        assertTrue(ctrl.revertFileToCommit("scripts/player_controller.gd"))
        assertFalse(ctrl.gitChanges.value.any { it.path == "scripts/player_controller.gd" })
        ctrl.createOrUpdateFile("scripts/extra_module.py", "def tick():\n    pass\n")
        val commit = ctrl.commitGitChanges("Add extra Python module")
        assertEquals("Add extra Python module", commit.message)
        assertTrue(ctrl.gitChanges.value.isEmpty())

        // 3. Android Visual Designer + Vector Asset Studio + SDK Deprecation Lint
        val modifiedLayoutPath = ctrl.insertAndroidDesignerWidget("BUTTON", "Launch Feature")
        assertTrue(ctrl.files.value.first { it.path == modifiedLayoutPath }.content.contains("Launch Feature"))
        val vectorPath = ctrl.createAndroidVectorAsset("rocket_badge", "bolt")
        assertTrue(ctrl.files.value.first { it.path == vectorPath }.content.contains("<vector"))

        ctrl.createOrUpdateFile(
            "android/app/src/main/java/com/example/studioapp/LegacyHelper.kt",
            "class LegacyHelper { fun go() { val x = AsyncTask(); val url = \"http://example.com\" } }"
        )
        val diags = ctrl.runCompileAndTestSync()
        assertTrue(diags.any { it.message.contains("ACS SDK Lint") && it.message.contains("AsyncTask") })

        // 4. Godot Timer Signal & Camera2D Tracking
        ctrl.addSceneNode(GodotNodeType.TIMER, "SpawnTimer", 100f, 100f)
        ctrl.addSceneNode(GodotNodeType.CAMERA_2D, "MainCam", 300f, 250f)
        repeat(30) { ctrl.stepSceneTickSync() }
        assertTrue(ctrl.godotSignalsLog.value.any { it.contains("SpawnTimer.timeout(") })
        ctrl.stopScene()
    }

    @Test
    fun vs_code_syntax_snippets_split_status_and_http_repo_zip_fetch_work() {
        // 1. Verify VS Code Syntax Highlighter, Snippets & Cursor Calculations
        val sampleKt = "@Composable\nfun Demo() {\n    val x = 42\n    // comment\n}"
        val highlighted = VsCodeEditorFeaturesEngine.highlightCode(sampleKt, IdeThemePreset.OBSIDIAN_STUDIO, "kotlin")
        assertEquals(sampleKt, highlighted.text)
        assertTrue("Expected syntax SpanStyles applied", highlighted.spanStyles.size >= 4)

        assertTrue(VsCodeEditorFeaturesEngine.snippetsForFile("player.gd").any { it.label == "func _ready" })
        assertTrue(VsCodeEditorFeaturesEngine.snippetsForFile("Main.kt").any { it.label == "@Composable" })
        assertEquals("GDScript", VsCodeEditorFeaturesEngine.languageDisplayName("scripts/player.gd"))
        assertEquals(2 to 5, VsCodeEditorFeaturesEngine.computeCursorLineCol("abc\n12345", 8))
        assertEquals(4, VsCodeEditorFeaturesEngine.lineStartOffset("abc\n12345", 2))

        // 2. Verify Split Editor & WordWrap/AutoSave Controller State
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_vscode_http_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )
        ctrl.toggleSplitEditorRight()
        assertNotNull(ctrl.splitRightPath.value)
        assertNotEquals(ctrl.activeTabPath.value, ctrl.splitRightPath.value)
        ctrl.toggleSplitEditorRight()
        assertNull(ctrl.splitRightPath.value)

        // 3. Verify HTTP ZIP Downloader for godot-master.zip & android-code-studio-main.zip via ephemeral loopback server
        val godotZip = buildZipBytes(
            "godot-master/SConstruct" to "env = Environment()",
            "godot-master/core/version.h" to "#define VERSION_MAJOR 4",
            "godot-master/modules/gdscript/gdscript.h" to "class GDScript {};"
        )
        val acsZip = buildZipBytes(
            "android-code-studio-main/settings.gradle.kts" to "rootProject.name=\"AndroidCS\"",
            "android-code-studio-main/xml-inflater/src/Inflater.kt" to "class LayoutInflater {}"
        )
        val server = com.sun.net.httpserver.HttpServer.create(java.net.InetSocketAddress("127.0.0.1", 0), 0)
        try {
            server.createContext("/godot-master.zip") { ex ->
                ex.sendResponseHeaders(200, godotZip.size.toLong())
                ex.responseBody.use { it.write(godotZip) }
            }
            server.createContext("/android-code-studio-main.zip") { ex ->
                ex.sendResponseHeaders(200, acsZip.size.toLong())
                ex.responseBody.use { it.write(acsZip) }
            }
            server.start()
            val port = server.address.port

            var progressBytes = 0L
            val gdMounted = ExternalRepoBridgeEngine.downloadAndMountFromUrl(
                kind = UpstreamRepoKind.GODOT,
                workspaceRoot = ws,
                urlOverride = "http://127.0.0.1:$port/godot-master.zip"
            ) { b -> progressBytes = b }
            assertTrue(progressBytes > 0)
            assertEquals(UpstreamRepoKind.GODOT, gdMounted.status.kind)
            assertTrue(gdMounted.status.detectedLayers.contains("core"))
            assertTrue(gdMounted.status.detectedLayers.contains("modules/gdscript"))

            val acsMounted = ExternalRepoBridgeEngine.downloadAndMountFromUrl(
                kind = UpstreamRepoKind.ANDROID_CODE_STUDIO,
                workspaceRoot = ws,
                urlOverride = "http://127.0.0.1:$port/android-code-studio-main.zip"
            )
            assertEquals(UpstreamRepoKind.ANDROID_CODE_STUDIO, acsMounted.status.kind)
            assertTrue(acsMounted.status.detectedLayers.contains("xml-inflater"))
        } finally {
            server.stop(0)
        }

        // 4. Verify Bundled assets/repos/*.zip auto-mount scanner
        val assetMounted = ExternalRepoBridgeEngine.scanBundledAssetZips(ws) { assetPath ->
            when (assetPath) {
                "repos/godot-master.zip" -> ByteArrayInputStream(godotZip)
                "repos/android-code-studio-main.zip" -> ByteArrayInputStream(acsZip)
                else -> null
            }
        }
        assertEquals(2, assetMounted.size)
        assertTrue(assetMounted.any { it.status.kind == UpstreamRepoKind.GODOT })
        assertTrue(assetMounted.any { it.status.kind == UpstreamRepoKind.ANDROID_CODE_STUDIO })

        ctrl.stopScene()
    }

    @Test
    fun reverse_engineered_kotlin_engines_vscode_godot_acs_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_re_engines_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )

        // 1. VscodeCoreKotlin: Comment toggle, Format document, RipgrepSearch, LSP completions
        val rawKt = "fun hi() {\nval a = 1\n}"
        val commented = VscodeCoreKotlin.CommandRegistry.executeTextCommand("editor.action.commentLine", rawKt, "kotlin")
        assertTrue(commented.lines().all { it.trimStart().startsWith("//") })
        val uncommented = VscodeCoreKotlin.CommandRegistry.executeTextCommand("editor.action.commentLine", commented, "kotlin")
        assertEquals(rawKt, uncommented)
        val formatted = VscodeCoreKotlin.CommandRegistry.executeTextCommand("editor.action.formatDocument", rawKt, "kotlin")
        assertTrue(formatted.contains("    val a = 1"))

        val searchHits = VscodeCoreKotlin.RipgrepSearch.searchWorkspace(ctrl.files.value, "Player")
        assertTrue(searchHits.isNotEmpty())
        assertTrue(VscodeCoreKotlin.LspCompletionEngine.suggestCompletions("gd", "func").any { it.contains("_ready") })

        // 2. GodotEngineKotlin: InputMap, SignalBus, PhysicsServer2D AABB resolution, RenderingServer2D Camera2D offset
        ctrl.godotSignalBus.connect("Player", "jumped", "HudTitle", "on_player_jump")
        ctrl.godotInputMap.actionPress("ui_right")
        val beforeX = ctrl.sceneNodes.value.first { it.name == "Player" }.x
        ctrl.stepSceneTickSync()
        val afterX = ctrl.sceneNodes.value.first { it.name == "Player" }.x
        assertTrue("Godot InputMap ui_right must move Player forward ($beforeX -> $afterX)", afterX > beforeX)
        assertTrue(ctrl.godotGroupManager.getNodesInGroup("player").contains("Player"))

        ctrl.addSceneNode(GodotNodeType.CAMERA_2D, "Cam", 100f, 100f)
        val camOffset = GodotEngineKotlin.RenderingServer2D.computeCameraOffset(ctrl.sceneNodes.value)
        assertNotEquals(0f, camOffset.first)

        // 3. AndroidCodeStudioKotlin: AAPT2 ResourceTable @string resolution + XML inflater + Missing Import quick-fix
        val customXml = """
            <LinearLayout android:orientation="vertical">
                <TextView android:text="@string/status_ready" />
                <CheckBox android:text="Remember Login" />
            </LinearLayout>
        """.trimIndent()
        val inflated = AndroidCodeStudioKotlin.XmlInflaterEngine.inflateXmlLayout(customXml, ctrl.acsResourceTable.value)
        assertEquals("Android Code Studio Live", inflated.first { it.tagName == "TextView" }.label)
        assertEquals("SWITCH", inflated.first { it.tagName == "CheckBox" }.kind)

        ctrl.createOrUpdateFile("android/app/src/main/java/com/example/studioapp/QuickFixSample.kt", "package demo\n@Composable fun Demo() { Button(onClick = {}) { Text(\"Hi\") } }")
        val addedImports = ctrl.fixMissingAndroidImportsActiveFile()
        assertTrue("Expected ACS completion to insert missing Compose imports", addedImports >= 3)
        val fixedCode = ctrl.files.value.first { it.path.endsWith("QuickFixSample.kt") }.content
        assertTrue(fixedCode.contains("import androidx.compose.material3.Button"))

        ctrl.stopScene()
    }

    @Test
    fun full_google_ai_studio_web_portals_and_any_provider_any_model_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ai = MultiProviderAgentAi(ctx, CredentialVault(ctx))

        // Verify all major providers & custom endpoint
        assertTrue(AiProviderKind.entries.containsAll(listOf(
            AiProviderKind.GEMINI,
            AiProviderKind.CLAUDE,
            AiProviderKind.OPENAI,
            AiProviderKind.OPENROUTER,
            AiProviderKind.GROQ,
            AiProviderKind.MISTRAL,
            AiProviderKind.SARVAM,
            AiProviderKind.CUSTOM_OPENAI
        )))

        ai.selectProvider(AiProviderKind.CLAUDE)
        ai.selectModel("claude-opus-4-20250514")
        ai.setTemperature(0.35f)
        ai.setCustomSystemPrompt("Respond in clean Kotlin.")
        assertEquals(AiProviderKind.CLAUDE, ai.config.value.provider)
        assertEquals("claude-opus-4-20250514", ai.config.value.model)
        assertEquals(0.35f, ai.config.value.temperature, 0.01f)
        assertEquals("Respond in clean Kotlin.", ai.config.value.customSystemPrompt)

        ai.selectProvider(AiProviderKind.OPENROUTER)
        ai.selectModel("anthropic/claude-sonnet-4")
        assertEquals("anthropic/claude-sonnet-4", ai.config.value.model)

        // Custom OpenAI-compatible (e.g. Ollama) works without requiring an API key
        ai.selectProvider(AiProviderKind.CUSTOM_OPENAI)
        ai.setCustomBaseUrl("http://127.0.0.1:11434/v1/")
        assertEquals("http://127.0.0.1:11434/v1", ai.config.value.customBaseUrl)
        assertTrue(ai.hasActiveApiKey())

        // Request builders handle temperature & multi-provider payloads
        val claudeJson = MultiProviderAgentAi.buildClaudeRequestBody("claude-sonnet-4-20250514", "sys", "usr", emptyList(), 0.4f)
        assertEquals(0.4, claudeJson.getDouble("temperature"), 0.02)
        val openAiJson = MultiProviderAgentAi.buildOpenAiRequestBody("gpt-4.1", "sys", "usr", emptyList(), false, 0.8f)
        assertEquals(0.8, openAiJson.getDouble("temperature"), 0.02)
        val geminiJson = MultiProviderAgentAi.buildGeminiRequestBody("sys", "usr", emptyList(), false, 0.5f)
        assertEquals(0.5, geminiJson.getJSONObject("generationConfig").getDouble("temperature"), 0.02)

        // Google AI Studio Web portals & URL normalizer
        assertTrue(AiStudioWebPortals.presets.any { it.url == "https://aistudio.google.com" })
        assertTrue(AiStudioWebPortals.presets.any { it.url == "https://console.anthropic.com" })
        assertEquals("https://aistudio.google.com", AiStudioWebPortals.normalizePortalUrl("aistudio.google.com"))
        assertEquals("http://127.0.0.1:11434", AiStudioWebPortals.normalizePortalUrl("http://127.0.0.1:11434"))
    }

    @Test
    @Config(sdk = [36], qualifiers = "w840dp-h412dp-land")
    fun agent_ai_studio_web_tab_and_ide_ai_coder_render_cleanly() {
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nav_agent").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("provider_chip_claude").performScrollTo().performClick()
        composeRule.onNodeWithTag("provider_chip_openrouter").performScrollTo().performClick()
        composeRule.onNodeWithTag("ai_temperature_slider").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("ai_system_prompt_input").performScrollTo().assertIsDisplayed()

        composeRule.onNodeWithTag("agent_tab_ai_studio_web").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("ai_studio_web_pane").assertIsDisplayed()
        composeRule.onNodeWithTag("ai_portal_aistudio").assertIsDisplayed()
        composeRule.onNodeWithTag("ai_portal_anthropic").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("ai_web_url_input").assertIsDisplayed()

        // Verify Tri-Pane IDE Voice/AI tab has direct "Ask AI -> Code" controls
        composeRule.onNodeWithTag("nav_ide").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("activity_tab_voice_ai").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("ide_ai_code_prompt_input").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("ide_ai_code_generate_btn").performScrollTo().assertIsDisplayed()
    }

    @Test
    fun repo_import_mode_in_app_vault_direct_file_and_acs_multi_language_build_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "ide_vault_acs_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(StudioCapability.entries.toSet())
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val ctrl = UnifiedIdeController(
            scope = CoroutineScope(SupervisorJob() + Dispatchers.Unconfined),
            compiler = compiler,
            capabilityManager = caps,
            hostDispatcher = stdLib,
            workspaceRoot = ws,
            initialAppDesign = AppDesign()
        )

        // 1. User Import Preference Modes (Full vs Essential vs Compiled Core)
        ctrl.setRepoImportMode(RepoImportMode.ESSENTIAL_LAYERS_ONLY)
        assertEquals(RepoImportMode.ESSENTIAL_LAYERS_ONLY, ctrl.repoImportMode.value)

        val godotZip = buildZipBytes(
            "godot-master/core/object/object.h" to "class Object {};",
            "godot-master/modules/gdscript/gdscript_vm.cpp" to "// GDScript VM",
            "godot-master/docs/random_notes.md" to "# non-essential doc",
            "godot-master/thirdparty/unused/foo.c" to "// non-essential thirdparty"
        )
        val essentialMount = ctrl.mountRepoFromZipStreamSync(
            kindOverride = UpstreamRepoKind.GODOT,
            zipName = "godot-master.zip",
            inputStream = ByteArrayInputStream(godotZip),
            importMode = RepoImportMode.ESSENTIAL_LAYERS_ONLY
        )
        assertTrue(essentialMount.indexedFiles.any { it.path.contains("core/object/object.h") })
        assertFalse(
            "ESSENTIAL_LAYERS_ONLY should filter out docs/ and thirdparty/",
            essentialMount.indexedFiles.any { it.path.contains("docs/random_notes.md") || it.path.contains("thirdparty/") }
        )

        val coreOnlyMount = ctrl.mountRepoFromZipStreamSync(
            kindOverride = UpstreamRepoKind.GODOT,
            zipName = "godot-master.zip",
            inputStream = ByteArrayInputStream(godotZip),
            importMode = RepoImportMode.COMPILED_KOTLIN_ONLY
        )
        assertEquals(0, coreOnlyMount.indexedFiles.size)

        // 2. In-App ZIP Vault + Direct File Upload inside app
        val stagedZip = ExternalRepoBridgeEngine.createReadyInAppRepoZip(UpstreamRepoKind.VSCODE, ws)
        assertTrue(stagedZip.exists())
        ctrl.refreshInAppVault()
        assertTrue(ctrl.inAppVaultZips.value.any { it.name == stagedZip.name })

        val directPath = ctrl.addDirectFileToRepo(
            UpstreamRepoKind.ANDROID_CODE_STUDIO,
            "src/custom_plugin.kt",
            "fun customPlugin() = \"ok\""
        )
        assertEquals("repos/android-code-studio/src/custom_plugin.kt", directPath)
        assertTrue(ctrl.files.value.any { it.path == directPath })

        // 3. Android Code Studio Multi-Language App Building Environment
        listOf(
            AppBuildLanguage.KOTLIN_COMPOSE to "MainActivity.kt",
            AppBuildLanguage.JAVA_ANDROID to "MainActivity.java",
            AppBuildLanguage.PYTHON_BRIDGE to "main.py",
            AppBuildLanguage.CPP_NDK to "native-lib.cpp",
            AppBuildLanguage.RUST_JNI to "lib.rs",
            AppBuildLanguage.HTML5_JS to "index.html",
            AppBuildLanguage.STUDIOLANG to "main.stl"
        ).forEach { (lang, expectedSuffix) ->
            val createdPath = ctrl.switchAndroidBuildLanguage(lang, AppDesign(buildLanguage = lang))
            assertTrue("Expected $lang to target $expectedSuffix, got $createdPath", createdPath.endsWith(expectedSuffix))
            assertEquals(lang, ctrl.acsBuildLanguage.value)
        }

        ctrl.setAcsBuildVariant("release")
        assertEquals("release", ctrl.acsBuildVariant.value)
        val phases = ctrl.runAndroidStudioGradleBuildPipeline(AppDesign(buildLanguage = AppBuildLanguage.STUDIOLANG))
        assertEquals(5, phases.size)
        assertTrue(phases.first().contains("variant=release"))
        assertTrue(phases.last().contains("PASS"))

        // 4. Accessibility settings helper returns cleanly without crashing
        assertFalse(StudioAccessibilityService.isEnabledInSettings(ctx))
        ctrl.stopScene()
    }

    @Test
    @Config(sdk = [36], qualifiers = "w840dp-h412dp-land")
    fun repo_in_app_vault_dialog_app_builder_acs_bridge_and_foreground_check_work_in_ui() {
        composeRule.waitForIdle()

        // 1. Open App Builder -> tap "Android CS IDE" -> lands in Unified IDE ACS mode with multi-lang & Gradle build controls
        composeRule.onNodeWithTag("nav_apps").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("open_in_acs_ide_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("unified_ide_screen").assertIsDisplayed()
        composeRule.onNodeWithTag("acs_gradle_build_btn").assertIsDisplayed()
        composeRule.onNodeWithTag("acs_build_lang_row").performScrollTo().performScrollToNode(hasTestTag("acs_build_lang_PYTHON_BRIDGE"))
        composeRule.onNodeWithTag("acs_build_lang_PYTHON_BRIDGE").performClick()
        composeRule.onNodeWithTag("acs_gradle_build_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("acs_build_phases_card").performScrollTo().assertIsDisplayed()

        // 2. Open Repos & Bridges tab -> click "In-App ZIP" -> opens In-App Vault & Import Mode Choice dialog (no system File Manager forced)
        composeRule.onNodeWithTag("activity_tab_repos_bridges").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("mount_repo_zip_btn").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("dialog_repo_mode_full_compile").assertIsDisplayed()
        composeRule.onNodeWithTag("dialog_repo_mode_essential_only").performClick()
        composeRule.onNodeWithTag("stage_in_app_zip_btn").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithTag("upload_direct_file_in_app_btn").performScrollTo().assertIsDisplayed()
        composeRule.onNodeWithText("Close").performClick()
        composeRule.waitForIdle()

        // 3. Navigate to Foreground Agent -> Foreground AI tab & verify Accessibility Test Inspect control
        composeRule.onNodeWithTag("nav_agent").performScrollTo().performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("agent_section_tabs_row").performScrollToNode(hasTestTag("agent_tab_foreground_ai"))
        composeRule.onNodeWithTag("agent_tab_foreground_ai").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("foreground_test_inspect_btn").performScrollTo().performClick()
        composeRule.waitForIdle()
    }

    private fun buildZipBytes(vararg entries: Pair<String, String>): ByteArray {
        val baos = ByteArrayOutputStream()
        ZipOutputStream(baos).use { zos ->
            entries.forEach { (path, body) ->
                zos.putNextEntry(ZipEntry(path))
                zos.write(body.toByteArray(Charsets.UTF_8))
                zos.closeEntry()
            }
        }
        return baos.toByteArray()
    }
}
