package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.agent.AgentAiProvider
import com.example.agent.AiProviderKind
import com.example.agent.MultiProviderAgentAi
import com.example.appbuilder.AndroidProjectGenerator
import com.example.appbuilder.AppBuildLanguage
import com.example.appbuilder.AppDesign
import com.example.appbuilder.OsTargetArch
import com.example.lang.LibraryImporter
import com.example.lang.StudioCapability
import com.example.runtime.CredentialVault
import com.example.runtime.NetworkShareManager
import com.example.runtime.StudioStdLib
import com.example.vm.BinaryHexEmitter
import com.example.vm.BinaryTarget
import com.example.vm.CapabilityManager
import com.example.vm.SelfHostedCompiler
import com.example.vm.StudioCompiler
import com.example.vm.StudioVm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.File
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SwatantraUpgradeTest {

    @Test
    fun gemini_thinking_parts_and_custom_openai_extraction_work() {
        val thinkingResp = """
            {
              "candidates": [{
                "content": {
                  "parts": [
                    {"text": "internal chain of thought", "thought": true},
                    {"text": "{\"summary\":\"Real reply after thought\"}"}
                  ]
                }
              }]
            }
        """.trimIndent()
        val extracted = MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.GEMINI, thinkingResp)
        assertEquals("{\"summary\":\"Real reply after thought\"}", extracted)

        val customReq = MultiProviderAgentAi.buildOpenAiRequestBody("llama-3.3-70b-versatile", "sys", "hi")
        assertEquals("llama-3.3-70b-versatile", customReq.getString("model"))
        val customResp = """{"choices":[{"message":{"content":"{\"summary\":\"Custom OpenAI OK\"}"}}]}"""
        assertEquals(
            "{\"summary\":\"Custom OpenAI OK\"}",
            MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.CUSTOM_OPENAI, customResp)
        )
    }

    @Test
    fun direct_binary_hex_and_elf64_emit_for_x86_arm64_and_riscv() {
        val compiler = StudioCompiler()
        val src = """
            let x = 42
            let y = x + 8
            return y
        """.trimIndent()

        BinaryTarget.entries.forEach { target ->
            val compiled = compiler.compile(src, useCache = false, target = target)
            assertTrue("Compile failed for $target", compiled.success)
            val art = compiled.binaryArtifact
            assertNotNull(art)
            assertTrue(art!!.bytes.size >= 16)
            assertTrue(art.hexDump.isNotBlank())
            assertTrue(art.disassembly.isNotBlank())
            if (target != BinaryTarget.STUDIO_VM_BIN) {
                // ELF magic: 0x7F 'E' 'L' 'F'
                assertEquals(0x7F.toByte(), art.bytes[0])
                assertEquals('E'.code.toByte(), art.bytes[1])
                assertEquals('L'.code.toByte(), art.bytes[2])
                assertEquals('F'.code.toByte(), art.bytes[3])
            }
        }
    }

    @Test
    fun self_hosted_compiler_bootstraps_stage1_to_stage2_hex_output() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "selfhost_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val caps = CapabilityManager(setOf(StudioCapability.FILE_ACCESS))
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))

        val res = runBlocking {
            SelfHostedCompiler.bootstrapCompile(
                targetSource = "let a = 10\nreturn a",
                compiler = compiler,
                capabilityManager = caps,
                hostDispatcher = stdLib,
                workspaceDir = ws
            )
        }
        assertTrue("Self-host failed: ${res.error}", res.success)
        assertTrue(res.stage1OpsCount > 10)
        assertTrue(res.stage2ByteCount >= 16)
        assertTrue(res.stage2HexOutput.contains("53544C31"))
    }

    @Test
    fun library_importer_resolves_studio_h_and_auto_appends_stl_lib_extension() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "libtest_${System.nanoTime()}").apply { mkdirs() }
        LibraryImporter.saveLibraryToDownloads(
            context = ctx,
            workspaceRoot = ws,
            rawName = "my_c_utils",
            authorLanguage = "c",
            bodyContent = "int clamp_score(int s) { return s; }"
        )

        val code = """
            #include <studio.h>
            #include <my_c_utils>
            let ver = studio_version()
            let sym = clamp_score()
            log.info(ver + " | " + sym)
            return sym
        """.trimIndent()

        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val compiled = compiler.compile(code, useCache = false)
        assertTrue("Expected #include compile success, diags=${compiled.diagnostics}", compiled.success)
        assertEquals(2, compiled.includedLibraries.size)

        val caps = CapabilityManager(setOf(StudioCapability.SYSTEM_INFO))
        val res = runBlocking { StudioVm(caps, StudioStdLib(ctx, ws, CredentialVault(ctx))).execute(compiled.bytecode!!) }
        assertTrue("VM error: ${res.error}", res.success)
        assertTrue(res.returnValue.asDisplayString().contains("my_c_utils.stl.lib::clamp_score"))
    }

    @Test
    fun deterministic_memory_arena_and_hardware_primitives_work_safely() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "memtest_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val code = """
            needs SYSTEM_INFO
            let arena = mem.arena_create(64)
            mem.write_u8(arena, 0, 255)
            mem.write_u32(arena, 4, 305419896)
            let b0 = mem.read_u8(arena, 0)
            let u32 = mem.read_u32(arena, 4)
            let hx = bin.to_hex_u32(u32)
            let cpu = hw.cpu_info()
            os.kernel_log("Boot cores=" + cpu.cores + " hx=" + hx)
            mem.arena_free(arena)
            return hx
        """.trimIndent()
        val compiled = compiler.compile(code, useCache = false)
        assertTrue("Compile failed: ${compiled.diagnostics}", compiled.success)

        val caps = CapabilityManager(setOf(StudioCapability.SYSTEM_INFO))
        val res = runBlocking { StudioVm(caps, StudioStdLib(ctx, ws, CredentialVault(ctx))).execute(compiled.bytecode!!) }
        assertTrue("VM failed: ${res.error}", res.success)
        assertEquals("0x12345678", res.returnValue.asDisplayString())
    }

    @Test
    fun ipv4_and_ipv6_loopback_data_share_transfers_files_cleanly() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "netshare_${System.nanoTime()}").apply { mkdirs() }
        val mgr = NetworkShareManager(ws)
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val testPort = 48991

        mgr.startReceiverServer(scope, testPort)
        runBlocking {
            var waited = 0
            while (!mgr.serverRunning.value && waited < 30) {
                delay(50)
                waited++
            }
            assertTrue("Receiver server did not start", mgr.serverRunning.value)

            val v4Entry = mgr.sendPayload("127.0.0.1", testPort, "shared_math.stl.lib", "# @stl.lib lang=studiolang\ndef pi() -> number:\n    return 3.14".toByteArray())
            assertTrue("IPv4 share failed: ${v4Entry.message}", v4Entry.ok)
            assertEquals("IPv4", v4Entry.protocol)
            assertTrue(File(ws, "libs/shared_math.stl.lib").exists())

            val v6Entry = mgr.sendPayload("::1", testPort, "hello_v6.txt", "IPv6 payload OK".toByteArray())
            // Some container sandboxes disable IPv6 kernel loopback; assert only when socket succeeded or handled honestly
            if (v6Entry.ok) {
                assertEquals("IPv6", v6Entry.protocol)
                assertTrue(File(ws, "shared_inbox/hello_v6.txt").exists())
            }
            mgr.stopReceiverServer()
        }
    }

    @Test
    fun app_builder_generates_custom_os_kernel_with_elf64_and_rust_cpp_java() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val outDir = File(ctx.filesDir, "osbuild_${System.nanoTime()}")
        val bakDir = File(ctx.filesDir, "osbak_${System.nanoTime()}")

        val osDesign = AppDesign(
            appName = "SwatantraOS",
            packageId = "com.example.swatantraos",
            buildLanguage = AppBuildLanguage.CUSTOM_OS_KERNEL,
            osTargetArch = OsTargetArch.AARCH64
        )
        val res = AndroidProjectGenerator.buildAndExport(osDesign, outDir, bakDir)
        assertTrue(res.success)
        assertNotNull(res.zipBytes)

        val entries = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(res.zipBytes!!)).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                entries += e.name
                e = zis.nextEntry
            }
        }
        assertTrue("os_kernel/kernel.stl" in entries)
        assertTrue("os_kernel/kernel.elf" in entries)
        assertTrue("os_kernel/linker.ld" in entries)
        assertTrue("os_kernel/boot_multiboot2.S" in entries)

        val rustDesign = AppDesign(
            appName = "RustApp",
            packageId = "com.example.rustapp",
            buildLanguage = AppBuildLanguage.RUST_JNI
        )
        val rustFiles = AndroidProjectGenerator.generateFiles(rustDesign).map { it.relativePath }
        assertTrue("rust_core/Cargo.toml" in rustFiles)
        assertTrue("rust_core/src/lib.rs" in rustFiles)

        val javaDesign = AppDesign(
            appName = "JavaApp",
            packageId = "com.example.javaapp",
            buildLanguage = AppBuildLanguage.JAVA_ANDROID
        )
        val javaFiles = AndroidProjectGenerator.generateFiles(javaDesign).map { it.relativePath }
        assertTrue("app/src/main/java/com/example/javaapp/MainActivity.java" in javaFiles)
    }

    @Test
    fun studiolang_perms_request_and_list_declared_work() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "permtest_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        var requestedPerm: String? = null
        val stdLib = StudioStdLib(
            context = ctx,
            workspaceRoot = ws,
            credentialVault = CredentialVault(ctx),
            requestPermissionCallback = { perm ->
                requestedPerm = perm
                true
            }
        )
        val code = """
            let declared = perms.list_declared()
            let mic_ok = perms.request("RECORD_AUDIO")
            let undeclared_ok = perms.request("android.permission.CAMERA")
            return [list.len(declared), mic_ok, undeclared_ok]
        """.trimIndent()
        val compiled = compiler.compile(code, useCache = false)
        assertTrue("Compile failed: ${compiled.diagnostics}", compiled.success)

        val res = runBlocking { StudioVm(CapabilityManager(emptySet()), stdLib).execute(compiled.bytecode!!) }
        assertTrue("VM failed: ${res.error}", res.success)
        assertEquals("android.permission.RECORD_AUDIO", requestedPerm)
        assertTrue(res.logs.any { it.message.contains("AndroidManifest.xml") })
    }

    @Test
    fun speaking_only_mode_and_first_launch_permissions_are_configured() {
        val app = ApplicationProvider.getApplicationContext<android.app.Application>()
        val vm = StudioViewModel(app)
        assertFalse(vm.speakingOnlyMode.value)
        vm.setSpeakingOnlyMode(true)
        assertTrue(vm.speakingOnlyMode.value)

        // First-launch prompt should initially be enabled until marked shown
        assertTrue(vm.showFirstLaunchPermissionsDialog.value)
        val missingRuntime = vm.getAllRuntimePermissionsToRequest()
        assertTrue(android.Manifest.permission.RECORD_AUDIO in missingRuntime)
        vm.markFirstLaunchPermissionsPromptShown()
        assertFalse(vm.showFirstLaunchPermissionsDialog.value)
    }

    @Test
    fun catalog_has_exact_500_triggers_400_actions_200_constraints_500_conditions_without_duplicates() {
        val allBuiltIns = com.example.nodes.NodeRegistry.builtInSpecs()
        val ids = allBuiltIns.map { it.id }
        assertEquals("Duplicate node IDs detected!", ids.size, ids.toSet().size)

        assertEquals(500, com.example.nodes.NodeRegistry.builtInCountFor(com.example.nodes.NodeCategory.TRIGGERS))
        assertEquals(400, com.example.nodes.NodeRegistry.builtInCountFor(com.example.nodes.NodeCategory.ACTIONS))
        assertEquals(200, com.example.nodes.NodeRegistry.builtInCountFor(com.example.nodes.NodeCategory.CONSTRAINTS))
        assertEquals(500, com.example.nodes.NodeRegistry.builtInCountFor(com.example.nodes.NodeCategory.CONDITIONS))

        // Spot check requested categories & fast O(1) lookup
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("trigger.pin_unlock"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("trigger.sms_otp_received"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("action.touch_custom"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("action.mobile_data_on"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("action.mobile_wifi_off"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("constraint.pin_unlocked_only"))
        assertNotNull(com.example.nodes.NodeRegistry.getSpec("cond.sms_has_otp"))
    }

    @Test
    fun pin_unlock_sms_otp_and_catalog_graph_execute_cleanly_in_vm() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "pin_sms_${System.nanoTime()}").apply { mkdirs() }
        val compiler = StudioCompiler(context = ctx, workspaceRoot = ws)
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))

        com.example.services.StudioTriggerBus.recordIncomingSms(
            "com.google.android.apps.messaging",
            "HDFC Bank",
            "Your OTP code is 739104 to verify login"
        )

        val code = """
            needs SYSTEM_INFO, CREDENTIAL_MANAGEMENT
            let set_ok = pin.set_code("4321")
            let bad_try = pin.verify("0000")
            let fails = pin.failed_attempts()
            let good_try = pin.verify("4321")
            let otp = sms.extract_otp()
            let sms_ok = sms.matches_filter("Bank", "OTP")
            let act = catalog.run_action("action.touch_custom", "Custom Touch", "Device Actions", "540,960")
            return [set_ok, bad_try, fails, good_try, otp, sms_ok, act.ok]
        """.trimIndent()
        val compiled = compiler.compile(code, useCache = false)
        assertTrue("Compile failed: ${compiled.diagnostics}", compiled.success)

        val caps = CapabilityManager(setOf(StudioCapability.SYSTEM_INFO, StudioCapability.CREDENTIAL_MANAGEMENT))
        val res = runBlocking { StudioVm(caps, stdLib).execute(compiled.bytecode!!) }
        assertTrue("VM failed: ${res.error}", res.success)
        val out = res.returnValue.asDisplayString()
        assertTrue("Expected bad_try=false & good_try=true & otp=739104, got $out", out.contains("739104") && out.contains("true"))

        // Verify GraphAstConverter converts catalog Trigger -> Constraint -> Action into compilable StudioLang
        val g = com.example.nodes.NodeGraph(
            name = "PinSmsFlow",
            nodes = listOf(
                com.example.nodes.GraphNode("n1", "trigger.pin_unlock", "PIN Unlock", 0f, 0f),
                com.example.nodes.GraphNode("n2", "constraint.pin_unlocked_only", "Unlocked Only", 240f, 0f),
                com.example.nodes.GraphNode("n3", "action.sms_extract_otp", "Extract OTP", 480f, 0f)
            ),
            wires = listOf(
                com.example.nodes.GraphWire("w1", "n1", "flow_out", "n2", "flow_in"),
                com.example.nodes.GraphWire("w2", "n2", "flow_out", "n3", "flow_in")
            )
        )
        val generatedStl = com.example.nodes.GraphAstConverter.graphToSource(g)
        val gCompiled = compiler.compile(generatedStl, useCache = false)
        assertTrue("Generated catalog graph STL failed to compile:\n$generatedStl\nDiags: ${gCompiled.diagnostics}", gCompiled.success)
    }
}
