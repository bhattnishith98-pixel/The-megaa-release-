package com.example

import android.app.Application
import android.content.Context
import android.util.Base64
import androidx.test.core.app.ApplicationProvider
import com.example.agent.*
import com.example.appbuilder.*
import com.example.lang.StudioCapability
import com.example.monetization.AdMobProfileConfig
import com.example.monetization.AdMobRewardedController
import com.example.monetization.MonetizationManager
import com.example.monetization.MonetizationProfile
import com.example.nodes.*
import com.example.runtime.CredentialVault
import com.example.runtime.PrivilegeBridge
import com.example.runtime.StudioStdLib
import com.example.vm.CapabilityManager
import com.example.vm.StudioCompiler
import com.example.vm.StudioVm
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayInputStream
import java.io.File
import java.security.KeyStore
import java.security.cert.X509Certificate
import java.util.zip.ZipInputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class UpgradeFeaturesTest {

    @Test
    fun byok_ai_providers_store_keys_build_payloads_and_parse_all_four_providers() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val vault = CredentialVault(ctx)
        val ai = MultiProviderAgentAi(ctx, vault)

        // Store & verify per-provider encrypted API keys
        ai.selectProvider(AiProviderKind.OPENAI)
        ai.selectModel("gpt-4o")
        ai.saveApiKey("sk-test-openai-99887766")
        assertTrue(ai.config.value.hasApiKey)
        assertTrue(ai.config.value.maskedKeyHint.contains("sk-"))

        ai.selectProvider(AiProviderKind.SARVAM)
        assertFalse(ai.config.value.hasApiKey)
        ai.saveApiKey("sarvam-test-123456")
        assertTrue(ai.config.value.hasApiKey)

        // Clear Sarvam key and ensure planFromBrief fails fast without key
        ai.clearApiKey()
        assertFalse(ai.config.value.hasApiKey)
        val missingThrown = runCatching {
            runBlocking { ai.planFromBrief("Build battery trigger", emptyList(), "") }
        }.exceptionOrNull()
        assertNotNull(missingThrown)
        assertTrue(missingThrown!!.message!!.contains("Missing API key"))

        // Verify request payloads and response extraction for Gemini, OpenAI, Claude, Sarvam
        val gemReq = MultiProviderAgentAi.buildGeminiRequestBody("sys", "usr", listOf("QUJD"))
        assertTrue(gemReq.toString().contains("inline_data"))
        val gemResp = """{"candidates":[{"content":{"parts":[{"text":"{\"summary\":\"Gem ok\"}"}]}}]}"""
        assertEquals("{\"summary\":\"Gem ok\"}", MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.GEMINI, gemResp))

        val oaiReq = MultiProviderAgentAi.buildOpenAiRequestBody("gpt-4o", "sys", "usr")
        assertEquals("gpt-4o", oaiReq.getString("model"))
        val oaiResp = """{"choices":[{"message":{"content":"{\"summary\":\"OAI ok\"}"}}]}"""
        assertEquals("{\"summary\":\"OAI ok\"}", MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.OPENAI, oaiResp))

        val claudeReq = MultiProviderAgentAi.buildClaudeRequestBody("claude-sonnet-4-20250514", "sys", "usr")
        assertEquals(4096, claudeReq.getInt("max_tokens"))
        val claudeResp = """{"content":[{"type":"text","text":"{\"summary\":\"Claude ok\"}"}]}"""
        assertEquals("{\"summary\":\"Claude ok\"}", MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.CLAUDE, claudeResp))

        val sarvamReq = MultiProviderAgentAi.buildSarvamRequestBody("sarvam-m", "sys", "usr")
        assertEquals("sarvam-m", sarvamReq.getString("model"))
        val sarvamResp = """{"choices":[{"message":{"content":"{\"summary\":\"Sarvam ok\"}"}}]}"""
        assertEquals("{\"summary\":\"Sarvam ok\"}", MultiProviderAgentAi.extractTextFromProviderResponse(AiProviderKind.SARVAM, sarvamResp))
    }

    @Test
    fun agent_target_modes_and_tool_executor_support_polyglot_triggers_blocks_and_apps() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "agent_poly_${System.nanoTime()}").apply { mkdirs() }
        val exec = AgentToolExecutor(ws, StudioCompiler(), CapabilityManager())

        val cfg = AiProviderConfig(
            provider = AiProviderKind.CLAUDE,
            targetMode = AgentTargetMode.CUSTOM_APP,
            targetLanguage = BlockLanguage.HTML5
        )
        val plan = MultiProviderAgentAi.parseAgentPlanJson(
            """{"summary":"HTML5 Counter","steps":["Generate HTML5"],"itemName":"HtmlCounter","proposedSourceCode":"<html><body><h1>Counter</h1></body></html>"}""",
            cfg
        )
        assertEquals("write_app_code", plan.toolCalls.first().toolName)

        var snap = AgentToolExecutor.WorkspaceSnapshot(NodeGraph(), "", AppDesign())
        val (okApp, _) = exec.executeTool(plan.toolCalls.first(), snap, onUpdate = { snap = it })
        assertTrue(okApp)
        assertEquals(AppBuildLanguage.HTML5_JS, snap.appDesign.buildLanguage)
        assertTrue(snap.appDesign.customHtml5Code.contains("<h1>Counter</h1>"))

        // Polyglot custom trigger creation via agent tool
        val (okTrig, _) = exec.executeTool(
            AgentToolCallSpec(
                "define_polyglot_trigger",
                mapOf(
                    "name" to "BatteryHighJson",
                    "language" to "JSON",
                    "sourceCode" to """{"trigger":"BatteryHighJson","when":{"level_gte":80}}""",
                    "summary" to "Fires at 80%+"
                )
            ),
            snap,
            onUpdate = { snap = it }
        )
        assertTrue(okTrig)
        val registered = NodeRegistry.customDefinitions.value.firstOrNull { it.name == "BatteryHighJson" }
        assertNotNull(registered)
        assertEquals(BlockLanguage.JSON, registered!!.language)
    }

    @Test
    fun privilege_bridge_shizuku_root_and_clipboard_capability_gating() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val ws = File(ctx.filesDir, "vm_priv_${System.nanoTime()}").apply { mkdirs() }
        val status = PrivilegeBridge.inspectEnvironment(ctx)
        assertNotNull(status.notes)

        // Compiling shizuku.exec auto-infers SHIZUKU_PRIVILEGED and VM blocks ungranted execution
        val compiler = StudioCompiler()
        val privCompile = compiler.compile("""shizuku.exec("id")""", useCache = false)
        assertTrue(privCompile.success)
        assertTrue(StudioCapability.SHIZUKU_PRIVILEGED in privCompile.bytecode!!.requiredCapabilities)
        val ungrantedVm = StudioVm(CapabilityManager(emptySet()), StudioStdLib(ctx, ws, CredentialVault(ctx)))
        val deniedRes = runBlocking { ungrantedVm.execute(privCompile.bytecode!!) }
        assertFalse(deniedRes.success)
        assertTrue(deniedRes.error.orEmpty().contains("SHIZUKU_PRIVILEGED"))

        // With declared capability, shizuku.is_available, root.is_available & clipboard run cleanly
        val code = """
            needs SYSTEM_INFO, SHIZUKU_PRIVILEGED, ROOT_SUPERUSER
            let s_ok = shizuku.is_available()
            let r_ok = root.is_available()
            clipboard.set("studio_clip")
            let clip = clipboard.get()
            log.info("s=" + s_ok + " r=" + r_ok + " c=" + clip)
        """.trimIndent()
        val compiled = compiler.compile(code, useCache = false)
        assertTrue("Expected compile success, diagnostics=${compiled.diagnostics}", compiled.success)

        val caps = CapabilityManager(
            setOf(StudioCapability.SYSTEM_INFO, StudioCapability.SHIZUKU_PRIVILEGED, StudioCapability.ROOT_SUPERUSER)
        )
        val stdLib = StudioStdLib(ctx, ws, CredentialVault(ctx))
        val res = runBlocking { StudioVm(caps, stdLib).execute(compiled.bytecode!!) }
        assertTrue("Expected VM success, error=${res.error}", res.success)
        assertTrue(res.logs.any { it.message.contains("studio_clip") })

        // Executing shizuku.exec without Shizuku installed reports honest unavailable error cleanly
        val shizukuRes = runBlocking { PrivilegeBridge.execShizuku(ctx, "id") }
        assertFalse(shizukuRes.ok)
        assertTrue(shizukuRes.stderr.contains("Shizuku") || shizukuRes.stderr.contains("rish"))
    }

    @Test
    fun polyglot_engine_validates_all_languages_and_stlpkg_preserves_language() {
        // JSON trigger matching
        val jsonCode = PolyglotEngine.starterTemplate(CustomDefinitionKind.TRIGGER, BlockLanguage.JSON, "ChargeAlert")
        val matchRes = PolyglotEngine.evaluateOrValidate(
            BlockLanguage.JSON,
            jsonCode,
            mapOf("level" to 85, "charging" to true)
        )
        assertTrue(matchRes.valid)
        assertEquals(true, matchRes.triggered)

        val noMatchRes = PolyglotEngine.evaluateOrValidate(
            BlockLanguage.JSON,
            jsonCode,
            mapOf("level" to 30, "charging" to true)
        )
        assertTrue(noMatchRes.valid)
        assertEquals(false, noMatchRes.triggered)

        // JS, HTML5, Kotlin, Python, C++ templates validate cleanly
        for (lang in BlockLanguage.entries) {
            val tmpl = PolyglotEngine.starterTemplate(CustomDefinitionKind.BLOCK, lang, "Sample$lang")
            val check = PolyglotEngine.evaluateOrValidate(lang, tmpl)
            assertTrue("Expected template valid for $lang: ${check.outputSummary}", check.valid)
        }

        // Catch invalid JS braces
        assertFalse(PolyglotEngine.evaluateOrValidate(BlockLanguage.JAVASCRIPT, "function x() { return 1").valid)

        // Package round-trip preserves BlockLanguage
        val def = CustomNodeDefinition(
            id = "custom.block.PyHelper",
            name = "PyHelper",
            kind = CustomDefinitionKind.BLOCK,
            summary = "Python helper",
            params = emptyList(),
            returnType = PortType.TEXT,
            requiredCapabilities = emptySet(),
            sourceCode = PolyglotEngine.starterTemplate(CustomDefinitionKind.BLOCK, BlockLanguage.PYTHON, "PyHelper"),
            language = BlockLanguage.PYTHON
        )
        val pkgBytes = StlPackageManager.exportPackage("PolyPack", "1.0.0", "Author", listOf(def))
        val manifest = StlPackageManager.inspectPackageForReview(pkgBytes)
        assertEquals(BlockLanguage.PYTHON, manifest.definitions.first().language)
    }

    @Test
    fun monetization_enforces_2_to_3_min_cadence_20_min_foreground_gate_and_300_inr_sub() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        ctx.getSharedPreferences("studio_monetization", Context.MODE_PRIVATE).edit().clear().apply()

        var fakeNow = 1_000_000L
        val mgr = MonetizationManager(ctx) { fakeNow }

        // Background ticks do NOT count toward the 20-min foreground timer
        mgr.onForegroundChanged(false)
        mgr.tickSeconds(2_000L)
        assertEquals(0L, mgr.state.value.foregroundSecondsWithoutAd)
        assertFalse(mgr.state.value.showPeriodicAdPrompt)
        assertFalse(mgr.state.value.showMandatoryAdGate)

        // Foreground ticks: 150s (2.5m) shows periodic test rewarded ad prompt
        mgr.onForegroundChanged(true)
        mgr.tickSeconds(150L)
        assertEquals(150L, mgr.state.value.foregroundSecondsWithoutAd)
        assertTrue(mgr.state.value.showPeriodicAdPrompt)
        assertFalse(mgr.state.value.showMandatoryAdGate)

        mgr.dismissPeriodicPromptLater()
        assertFalse(mgr.state.value.showPeriodicAdPrompt)

        // Advance past 20 minutes total (1200s) -> mandatory "This is Ad Time" gate activates
        mgr.tickSeconds(1050L)
        assertTrue(mgr.state.value.showMandatoryAdGate)
        assertEquals(0L, mgr.state.value.foregroundSecondsRemainingBeforeGate)

        // Seeing a test rewarded ad clears the gate & resets countdown
        mgr.completeTestRewardedAd()
        assertFalse(mgr.state.value.showMandatoryAdGate)
        assertEquals(0L, mgr.state.value.foregroundSecondsWithoutAd)
        assertEquals(1, mgr.state.value.totalTestAdsWatched)

        // ₹300/month subscription removes ads & gate for 30 days
        assertEquals(300, MonetizationManager.SUBSCRIPTION_PRICE_INR)
        mgr.activateMonthlySubscriptionTest()
        assertTrue(mgr.state.value.isSubscribed)
        mgr.tickSeconds(5_000L)
        assertFalse(mgr.state.value.showPeriodicAdPrompt)
        assertFalse(mgr.state.value.showMandatoryAdGate)
        assertEquals(0L, mgr.state.value.foregroundSecondsWithoutAd)
    }

    @Test
    fun app_builder_exports_kotlin_and_html5_projects_with_ci_and_valid_pkcs12_keystore() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        val outDir = File(ctx.filesDir, "app_poly_${System.nanoTime()}")
        val bakDir = File(ctx.filesDir, "bak_poly_${System.nanoTime()}")

        val htmlDesign = AppDesign(
            appName = "HtmlDash",
            packageId = "com.example.htmldash",
            buildLanguage = AppBuildLanguage.HTML5_JS,
            customHtml5Code = "<html><body><h1>Dash</h1><script src=\"app.js\"></script></body></html>",
            customJsCode = "console.log('ready');",
            customCppCode = "extern \"C\" int ping() { return 1; }",
            customPythonCode = "print('py_asset')"
        )
        val build = AndroidProjectGenerator.buildAndExport(htmlDesign, outDir, bakDir)
        assertTrue(build.success)
        assertNotNull(build.zipBytes)

        // Inspect generated ZIP entries
        val entries = mutableSetOf<String>()
        ZipInputStream(ByteArrayInputStream(build.zipBytes!!)).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                entries += e.name
                e = zis.nextEntry
            }
        }
        assertTrue("app/src/main/assets/index.html" in entries)
        assertTrue("app/src/main/assets/app.js" in entries)
        assertTrue("app/src/main/cpp/native_module.cpp" in entries)
        assertTrue("app/src/main/assets/scripts/main.py" in entries)
        assertTrue(".github/workflows/build-app.yml" in entries)

        // Generate PKCS12 release keystore & cryptographically verify certificate + private key
        val ksRes = ReleaseKeystoreGenerator.generatePkcs12Keystore(
            KeystoreGenerationConfig(
                alias = "upload",
                storePassword = "storePass99",
                keyPassword = "keyPass99",
                commonName = "Studio Dev",
                organization = "Studio Org",
                countryCode = "IN",
                validityDays = 9125
            )
        )
        assertTrue(ksRes.keystoreBytes.isNotEmpty())
        assertTrue(ksRes.sha256Fingerprint.contains(":"))
        assertTrue(ksRes.sha1Fingerprint.contains(":"))

        val decoded = Base64.decode(ksRes.base64Encoded, Base64.NO_WRAP)
        assertArrayEquals(ksRes.keystoreBytes, decoded)

        val ks = KeyStore.getInstance("PKCS12")
        ks.load(ByteArrayInputStream(ksRes.keystoreBytes), "storePass99".toCharArray())
        val privKey = ks.getKey("upload", "keyPass99".toCharArray())
        val cert = ks.getCertificate("upload") as X509Certificate
        assertNotNull(privKey)
        assertNotNull(cert)
        cert.verify(cert.publicKey)
        assertTrue(cert.subjectX500Principal.name.contains("Studio Dev"))
    }

    @Test
    fun monetization_json_profile_and_admob_fallback_work_in_test_mode() {
        val ctx = ApplicationProvider.getApplicationContext<Context>()
        ctx.getSharedPreferences("studio_monetization", Context.MODE_PRIVATE).edit().clear().apply()

        val mgr = MonetizationManager(ctx)
        assertTrue(mgr.state.value.profile.isTestMode)
        assertEquals(AdMobProfileConfig.DEFAULT_TEST_REWARDED_AD_UNIT_ID, mgr.state.value.adUnitId)

        // User edits JSON profile with UPI ID & custom AdMob unit while keeping mode = "TEST"
        val editedJson = """
            {
              "mode": "TEST",
              "admob": {
                "app_id": "ca-app-pub-1234567890123456~1234567890",
                "rewarded_ad_unit_id": "ca-app-pub-1234567890123456/0987654321",
                "cadence_seconds": 160,
                "foreground_gate_seconds": 1200,
                "use_sdk_when_available": true
              },
              "upi": {
                "upi_id": "studio@okaxis",
                "payee_name": "Studio Pro",
                "subscription_amount_inr": 300,
                "subscription_days": 30,
                "billing_mode": "TEST_LOCAL"
              }
            }
        """.trimIndent()
        val parsed = mgr.updateProfileFromJson(editedJson)
        assertTrue(parsed.isSuccess)
        val prof = parsed.getOrThrow()
        assertEquals("studio@okaxis", prof.upi.upiId)
        assertTrue(prof.validate().isEmpty())
        assertTrue(prof.buildUpiPaymentUri()!!.contains("pa=studio%40okaxis"))
        assertTrue(prof.buildUpiPaymentUri()!!.contains("am=300"))
        // TEST mode enforces test ad unit even when real unit is stored in JSON
        assertEquals(AdMobProfileConfig.DEFAULT_TEST_REWARDED_AD_UNIT_ID, mgr.state.value.adUnitId)

        // Switching mode to LIVE switches effectiveRewardedAdUnitId to stored unit
        val liveJson = editedJson.replace("\"mode\": \"TEST\"", "\"mode\": \"LIVE\"")
        assertTrue(mgr.updateProfileFromJson(liveJson).isSuccess)
        assertEquals("ca-app-pub-1234567890123456/0987654321", mgr.state.value.adUnitId)

        // Persistence reload preserves profile
        val reloadedMgr = MonetizationManager(ctx)
        assertEquals("studio@okaxis", reloadedMgr.state.value.profile.upi.upiId)
        assertEquals("ca-app-pub-1234567890123456/0987654321", reloadedMgr.state.value.adUnitId)

        // AdMobRewardedController falls back cleanly when no loaded SDK ad / Activity exists
        val ctrl = AdMobRewardedController(ctx)
        var fallbackTriggered = false
        ctrl.showRewardedAdOrFallback(
            activity = null,
            adUnitId = AdMobProfileConfig.DEFAULT_TEST_REWARDED_AD_UNIT_ID,
            useSdkWhenAvailable = true,
            onRewardEarned = {},
            onFallbackToTestPlayer = { fallbackTriggered = true }
        )
        assertTrue(fallbackTriggered)
    }
}
